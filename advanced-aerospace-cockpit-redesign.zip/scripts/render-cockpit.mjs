#!/usr/bin/env -S npx tsx
/* ─────────────────────────────────────────────────────────────────────────────
   render-cockpit.mjs — direct scene-graph clay & silhouette audit rasteriser.

   Imports the ACTUAL `buildCockpit` Three.js scene graph from `src/cockpit/cockpit.ts`
   (including RMF sweeps, thick-shell lofts, pocketed CNC bezels and InstancedMesh
   hardware) with a minimal 2D canvas shim and software-rasterises smooth vertex
   normals + screen-space cavity AO into PNG files for geometry verification.

   USAGE
     npx tsx scripts/render-cockpit.mjs              # all four study views
     npx tsx scripts/render-cockpit.mjs --view pilot # single view
   Output: renders/cockpit-<view>.png
   ──────────────────────────────────────────────────────────────────────────── */

import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';
import * as THREE from 'three';

// Minimal zero-dependency Canvas2D shim so procedural texture builders run in Node
function makeStubCanvas(w = 256, h = 256) {
  const buf = new Uint8ClampedArray(w * h * 4);
  const grad = () => ({ addColorStop: () => undefined });
  const ctx = {
    fillStyle: '#808080',
    strokeStyle: '#808080',
    lineWidth: 1,
    font: '12px monospace',
    textAlign: 'left',
    textBaseline: 'alphabetic',
    globalAlpha: 1,
    globalCompositeOperation: 'source-over',
    fillRect: () => undefined,
    clearRect: () => undefined,
    strokeRect: () => undefined,
    beginPath: () => undefined,
    closePath: () => undefined,
    moveTo: () => undefined,
    lineTo: () => undefined,
    arc: () => undefined,
    bezierCurveTo: () => undefined,
    quadraticCurveTo: () => undefined,
    fill: () => undefined,
    stroke: () => undefined,
    clip: () => undefined,
    save: () => undefined,
    restore: () => undefined,
    translate: () => undefined,
    rotate: () => undefined,
    scale: () => undefined,
    fillText: () => undefined,
    createLinearGradient: grad,
    createRadialGradient: grad,
    getImageData: (_x, _y, iw, ih) => ({ data: new Uint8ClampedArray(iw * ih * 4).fill(128) }),
    createImageData: (iw, ih) => ({ data: new Uint8ClampedArray(iw * ih * 4) }),
    putImageData: () => undefined,
  };
  return { width: w, height: h, getContext: () => ctx, _buf: buf };
}

globalThis.document = {
  createElement: (tag) => (tag === 'canvas' ? makeStubCanvas(256, 256) : {}),
};
globalThis.window = globalThis;

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const OUT_DIR = path.resolve(ROOT, 'renders');
const WIDTH = 960;
const HEIGHT = 600;

const { buildMaterials } = await import(path.join(ROOT, 'src/cockpit/materials.ts'));
const { buildCockpit } = await import(path.join(ROOT, 'src/cockpit/cockpit.ts'));
const { STUDY_VIEWS } = await import(path.join(ROOT, 'src/data/blueprint.ts'));

const mats = buildMaterials();
const cockpit = buildCockpit(mats);
cockpit.group.updateMatrixWorld(true);

const screenSet = new Set(cockpit.screenMeshes);
const decalSet = new Set(cockpit.decals);

function crc32(buf) {
  let c = ~0;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xedb88320 & -(c & 1));
  }
  return ~c >>> 0;
}

function encodePng(width, height, rgb) {
  const raw = Buffer.alloc((width * 3 + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (width * 3 + 1)] = 0;
    Buffer.from(rgb.buffer, rgb.byteOffset + y * width * 3, width * 3).copy(raw, y * (width * 3 + 1) + 1);
  }
  const chunk = (type, data) => {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(body));
    return Buffer.concat([len, body, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 2;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

function renderClayView(view) {
  const camera = new THREE.PerspectiveCamera(view.fov, WIDTH / HEIGHT, 0.04, 100);
  camera.position.set(...view.position);
  camera.lookAt(...view.target);
  camera.updateMatrixWorld(true);
  camera.updateProjectionMatrix();

  const viewMat = camera.matrixWorldInverse;
  const projMat = camera.projectionMatrix;
  const zbuf = new Float32Array(WIDTH * HEIGHT).fill(Infinity);
  const viewZ = new Float32Array(WIDTH * HEIGHT).fill(Infinity);
  const shadeBuf = new Float32Array(WIDTH * HEIGHT).fill(0.5);

  const keyDir = new THREE.Vector3(2.8, 4.4, 1.9).normalize();
  const backDir = new THREE.Vector3(-0.4, 0.35, -0.85).normalize();
  const vW = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()];
  const vV = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()];
  const vC = [new THREE.Vector4(), new THREE.Vector4(), new THREE.Vector4()];
  const nW = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()];
  const instM = new THREE.Matrix4();
  const totM = new THREE.Matrix4();
  const nrmM = new THREE.Matrix3();

  cockpit.group.traverseVisible((obj) => {
    if (!(obj instanceof THREE.Mesh)) return;
    const mat = Array.isArray(obj.material) ? obj.material[0] : obj.material;
    if (!mat) return;
    if (
      mat === mats.glass ||
      mat === mats.screenGlass ||
      mat === mats.hudGlass ||
      mat === mats.glassEdge ||
      screenSet.has(obj) ||
      decalSet.has(obj) ||
      mat.transparent
    ) {
      return;
    }
    const geo = obj.geometry;
    const pos = geo.getAttribute('position');
    if (!pos) return;
    if (!geo.getAttribute('normal')) geo.computeVertexNormals();
    const nrm = geo.getAttribute('normal');
    const idx = geo.getIndex();
    const tris = (idx ? idx.count : pos.count) / 3;
    const count = obj.isInstancedMesh ? obj.count : 1;

    for (let inst = 0; inst < count; inst++) {
      if (obj.isInstancedMesh) {
        obj.getMatrixAt(inst, instM);
        totM.multiplyMatrices(obj.matrixWorld, instM);
      } else {
        totM.copy(obj.matrixWorld);
      }
      nrmM.getNormalMatrix(totM);

      for (let t = 0; t < tris; t++) {
        const ids = [
          idx ? idx.getX(t * 3) : t * 3,
          idx ? idx.getX(t * 3 + 1) : t * 3 + 1,
          idx ? idx.getX(t * 3 + 2) : t * 3 + 2,
        ];
        let clip = false;
        for (let k = 0; k < 3; k++) {
          vW[k].fromBufferAttribute(pos, ids[k]).applyMatrix4(totM);
          vV[k].copy(vW[k]).applyMatrix4(viewMat);
          if (vV[k].z > -0.04) { clip = true; break; }
          vC[k].set(vV[k].x, vV[k].y, vV[k].z, 1).applyMatrix4(projMat);
          nW[k].fromBufferAttribute(nrm, ids[k]).applyMatrix3(nrmM).normalize();
        }
        if (clip) continue;

        const sx0 = (vC[0].x / vC[0].w * 0.5 + 0.5) * WIDTH;
        const sy0 = (-vC[0].y / vC[0].w * 0.5 + 0.5) * HEIGHT;
        const sx1 = (vC[1].x / vC[1].w * 0.5 + 0.5) * WIDTH;
        const sy1 = (-vC[1].y / vC[1].w * 0.5 + 0.5) * HEIGHT;
        const sx2 = (vC[2].x / vC[2].w * 0.5 + 0.5) * WIDTH;
        const sy2 = (-vC[2].y / vC[2].w * 0.5 + 0.5) * HEIGHT;

        const area = (sx1 - sx0) * (sy2 - sy0) - (sy1 - sy0) * (sx2 - sx0);
        if (Math.abs(area) < 1e-4 || (mat.side !== THREE.DoubleSide && area > 0)) continue;

        const minX = Math.max(0, Math.floor(Math.min(sx0, sx1, sx2)));
        const maxX = Math.min(WIDTH - 1, Math.ceil(Math.max(sx0, sx1, sx2)));
        const minY = Math.max(0, Math.floor(Math.min(sy0, sy1, sy2)));
        const maxY = Math.min(HEIGHT - 1, Math.ceil(Math.max(sy0, sy1, sy2)));
        const iw0 = 1 / vC[0].w, iw1 = 1 / vC[1].w, iw2 = 1 / vC[2].w;
        const z0 = vC[0].z * iw0, z1 = vC[1].z * iw1, z2 = vC[2].z * iw2;

        for (let py = minY; py <= maxY; py++) {
          const cy = py + 0.5;
          for (let px = minX; px <= maxX; px++) {
            const cx = px + 0.5;
            const w0 = ((sx1 - cx) * (sy2 - cy) - (sy1 - cy) * (sx2 - cx)) / area;
            const w1 = ((sx2 - cx) * (sy0 - cy) - (sy2 - cy) * (sx0 - cx)) / area;
            const w2 = 1 - w0 - w1;
            if (w0 < 0 || w1 < 0 || w2 < 0) continue;
            const ndcZ = w0 * z0 + w1 * z1 + w2 * z2;
            const pIdx = py * WIDTH + px;
            if (ndcZ < -1 || ndcZ > 1 || ndcZ >= zbuf[pIdx]) continue;
            zbuf[pIdx] = ndcZ;

            const pw0 = w0 * iw0, pw1 = w1 * iw1, pw2 = w2 * iw2;
            const invP = 1 / (pw0 + pw1 + pw2);
            const b0 = pw0 * invP, b1 = pw1 * invP, b2 = pw2 * invP;
            viewZ[pIdx] = -(b0 * vV[0].z + b1 * vV[1].z + b2 * vV[2].z);

            let nx = b0 * nW[0].x + b1 * nW[1].x + b2 * nW[2].x;
            let ny = b0 * nW[0].y + b1 * nW[1].y + b2 * nW[2].y;
            let nz = b0 * nW[0].z + b1 * nW[1].z + b2 * nW[2].z;
            const nl = Math.hypot(nx, ny, nz) || 1;
            nx /= nl; ny /= nl; nz /= nl;

            const ndl = Math.max(0, nx * keyDir.x + ny * keyDir.y + nz * keyDir.z);
            const ndb = Math.max(0, nx * backDir.x + ny * backDir.y + nz * backDir.z);
            shadeBuf[pIdx] = 0.72 * (0.26 + 0.20 * (0.5 + 0.5 * ny) + 0.62 * ndl + 0.16 * ndb);
          }
        }
      }
    }
  });

  const rgb = new Uint8Array(WIDTH * HEIGHT * 3);
  const aoOffsets = [[-2, 0], [2, 0], [0, -2], [0, 2], [-5, -4], [5, -4], [-5, 4], [5, 4]];
  for (let y = 0; y < HEIGHT; y++) {
    for (let x = 0; x < WIDTH; x++) {
      const pIdx = y * WIDTH + x;
      let v = shadeBuf[pIdx];
      const vz = viewZ[pIdx];
      if (vz < Infinity) {
        let occ = 0;
        for (const [ox, oy] of aoOffsets) {
          const sx = x + ox, sy = y + oy;
          if (sx >= 0 && sx < WIDTH && sy >= 0 && sy < HEIGHT) {
            const dz = vz - viewZ[sy * WIDTH + sx];
            if (dz > 0.003 && dz < 0.15) occ++;
          }
        }
        v *= 1 - (occ / aoOffsets.length) * 0.48;
      }
      const srgb = Math.round(Math.pow(Math.min(1, Math.max(0, v)), 1 / 2.2) * 255);
      rgb[pIdx * 3] = srgb;
      rgb[pIdx * 3 + 1] = srgb;
      rgb[pIdx * 3 + 2] = Math.max(0, srgb - 2);
    }
  }

  fs.mkdirSync(OUT_DIR, { recursive: true });
  const outPath = path.join(OUT_DIR, `cockpit-${view.id}.png`);
  fs.writeFileSync(outPath, encodePng(WIDTH, HEIGHT, rgb));
  console.log(`Wrote ${outPath}`);
}

const argIdx = process.argv.indexOf('--view');
const targetView = argIdx !== -1 ? process.argv[argIdx + 1] : null;
const list = targetView ? STUDY_VIEWS.filter((v) => v.id === targetView) : STUDY_VIEWS;
for (const v of list) renderClayView(v);
