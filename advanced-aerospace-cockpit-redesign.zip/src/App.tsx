import { useCallback, useEffect, useState } from 'react';
import { CockpitCanvas } from './components/CockpitCanvas';
import { Dossier } from './components/Dossier';
import {
  SECTIONS,
  STUDY_VIEWS,
  VIEW_COPY,
  type SectionId,
  type ViewId,
} from './data/blueprint';

/* The six command keys follow a 2.10 m reference arc; the outer column is held
   at 1.94 m so the end keys cannot be clipped by the viewport edge. These are
   design-drawing coordinates, scaled to the rendered key arc below. */
const COMMAND_ARC = { radius: 2.1, outerColumn: 1.94, unit: 266 };
const KEY_ANGLES = [112, 103.2, 94.4, 85.6, 76.8, 67.2];
const KEY_CENTER_Y = 573;
const ARC_R = COMMAND_ARC.radius * COMMAND_ARC.unit;


function LogoMark() {
  return (
    <svg className="logo-mark" viewBox="0 0 34 34" aria-hidden="true">
      <path d="M17 2.5 31 26H23.4L17 14.8 10.6 26H3Z" fill="none" stroke="currentColor" strokeWidth="1.3" />
      <path d="M17 12.5 22.4 22H11.6Z" fill="currentColor" opacity=".9" />
      <circle cx="17" cy="29.5" r="1.45" fill="currentColor" />
    </svg>
  );
}

function Clock() {
  const [time, setTime] = useState('--:--:--');
  useEffect(() => {
    const fmt = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Ho_Chi_Minh',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    });
    const tick = () => setTime(fmt.format(new Date()));
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);
  return (
    <div className="clock" aria-label="Local mission control time, UTC plus 7">
      <span>UTC+07</span>
      <strong>{time}</strong>
    </div>
  );
}

export default function App() {
  const [sectionId, setSectionId] = useState<SectionId>('flight');
  const [view, setView] = useState<ViewId>('pilot');
  const [throttle, setThrottle] = useState(0.62);
  const [grayscale, setGrayscale] = useState(false);
  const [dossierOpen, setDossierOpen] = useState(false);
  const [dossierTab, setDossierTab] = useState('geometry');
  const [callouts, setCallouts] = useState(true);
  const [webglError, setWebglError] = useState(false);

  const section = SECTIONS.find((s) => s.id === sectionId) ?? SECTIONS[0];
  const activeView = STUDY_VIEWS.find((v) => v.id === view) ?? STUDY_VIEWS[0];

  const openDossier = useCallback((tab = 'geometry') => {
    setDossierTab(tab);
    setDossierOpen(true);
  }, []);

  const onCanvasError = useCallback(() => setWebglError(true), []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && /input|textarea|select/i.test(target.tagName)) return;
      if (e.key >= '1' && e.key <= '6') {
        setSectionId(SECTIONS[Number(e.key) - 1].id);
        return;
      }
      const map: Record<string, ViewId> = { a: 'pilot', b: 'command', c: 'overhead', d: 'detail' };
      const k = e.key.toLowerCase();
      if (map[k]) {
        setView(map[k]);
        return;
      }
      if (k === 'g') setGrayscale((v) => !v);
      if (k === 'c') setCallouts((v) => !v);
      if (e.key === 'Escape') setDossierOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div className={`app ${grayscale ? 'is-audit' : ''} ${dossierOpen ? 'has-dossier' : ''}`}>
      <CockpitCanvas
        section={section}
        view={view}
        throttle={throttle}
        grayscale={grayscale}
        onError={onCanvasError}
      />
      <div className="scene-grade" aria-hidden="true" />
      <div className="scene-grain" aria-hidden="true" />

      {webglError && (
        <div className="webgl-error" role="alert">
          <span className="micro amber">RENDERER OFFLINE</span>
          <h2>This study needs WebGL.</h2>
          <p>
            The cockpit scene could not start in this browser. Enable hardware acceleration and
            reload to inspect the geometry in real time.
          </p>
        </div>
      )}

      <header className="topbar">
        <div className="brand">
          <LogoMark />
          <div className="brand-type">
            <strong>AETHERWORKS</strong>
            <span>ADVANCED FLIGHT SYSTEMS</span>
          </div>
        </div>

        <nav className="topnav" aria-label="Primary navigation">
          <button onClick={() => { setSectionId('flight'); setView('pilot'); }}>Cockpit</button>
          <button onClick={() => openDossier('geometry')}>Architecture</button>
          <button onClick={() => openDossier('human')}>Human factors</button>
          <button onClick={() => openDossier('validation')}>Method</button>
        </nav>

        <div className="topmeta">
          <span className="online"><i /> FLIGHT DECK ONLINE</span>
          <Clock />
          <button className="dossier-trigger" onClick={() => openDossier('geometry')}>
            <span>DOSSIER</span>
            <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 3l5 5-5 5" /></svg>
          </button>
        </div>
      </header>

      {grayscale && (
        <div className="audit-banner" role="status">
          <span className="audit-mark">◎</span>
          <div>
            <strong>GEOMETRY AUDIT</strong>
            <span>Materials · emissives · exterior disabled</span>
          </div>
          <span className="audit-coords">VIEW {activeView.index} / FOV {activeView.fov}°</span>
        </div>
      )}

      <main className={`stage ${grayscale ? 'is-audit' : ''}`}>
        <section className="hero" aria-labelledby="hero-title">
          <p className="eyebrow">
            <span className="rule" />
            HX-9 // COMMAND MODULE
          </p>
          <h1 id="hero-title">
            Made to be
            <em>flown.</em>
          </h1>
          <p className="lede">
            An orbital flight deck rebuilt from its structure outward — lofted pressure shell,
            swept canopy frames and machined interfaces, arranged around one seated human.
          </p>
          <div className="hero-actions">
            <button className="btn btn-primary" onClick={() => openDossier('geometry')}>
              Read the dossier
              <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10M9 3l5 5-5 5" /></svg>
            </button>
            <button className="btn btn-ghost" onClick={() => setGrayscale((v) => !v)}>
              {grayscale ? 'Return to materials' : 'Grey geometry audit'}
            </button>
          </div>
          <div className="hero-specs">
            <div><strong>1.08<span>m</span></strong><small>Design eye</small></div>
            <div><strong>15<span>°</span></strong><small>MIP tilt</small></div>
            <div><strong>24<span>°</span></strong><small>Wing wrap</small></div>
            <div><strong>17<span>°</span></strong><small>Nose sight</small></div>
          </div>
          <div className="mobile-views" aria-label="Study views">
            {STUDY_VIEWS.map((v) => (
              <button
                key={v.id}
                className={v.id === view ? 'is-active' : ''}
                onClick={() => setView(v.id)}
                aria-label={`${v.label} camera`}
              >
                {v.index}
              </button>
            ))}
          </div>
        </section>

        <aside className="view-rail" aria-label="Camera study views">
          <div className="rail-head">
            <span className="micro">STUDY VIEWS</span>
            <span className="micro faint">{activeView.index} / 04</span>
          </div>
          <div className="rail-list">
            {STUDY_VIEWS.map((v) => (
              <button
                key={v.id}
                className={`view-btn ${view === v.id ? 'is-active' : ''}`}
                onClick={() => setView(v.id)}
                aria-pressed={view === v.id}
              >
                <span className="v-index">{v.index}</span>
                <span className="v-copy">
                  <strong>{v.label}</strong>
                  <small>{v.caption}</small>
                </span>
                <span className="v-tick" aria-hidden="true" />
              </button>
            ))}
          </div>
          <button
            className={`rail-callouts ${callouts ? 'is-on' : ''}`}
            onClick={() => setCallouts((v) => !v)}
            aria-pressed={callouts}
          >
            <span className="mini-dot" /> CALLOUTS {callouts ? 'ON' : 'OFF'}
          </button>
          <p className="rail-hint">DRAG TO LOOK · SCROLL ZOOM · DBL-CLICK RESET</p>
        </aside>

        <aside className="telemetry" aria-label="System telemetry">
          <div className="tel-head">
            <span className="micro">SYSTEM {section.index} / 06</span>
            <span className="live-tag"><i /> LIVE</span>
          </div>
          <div className="tel-title">
            <span className="code">{section.code}</span>
            <h2>{section.title}</h2>
          </div>
          <p className="kicker">{section.kicker}</p>
          <p className="tel-desc">{section.description}</p>

          <div className="tel-stats">
            {section.stats.map((s) => (
              <div key={s.k}>
                <span>{s.k}</span>
                <strong>{s.v}<small>{s.unit}</small></strong>
              </div>
            ))}
          </div>

          <div className="tel-graph" aria-hidden="true">
            <svg viewBox="0 0 280 46" preserveAspectRatio="none">
              <defs>
                <linearGradient id="telFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0" stopColor={section.color} stopOpacity=".28" />
                  <stop offset="1" stopColor={section.color} stopOpacity="0" />
                </linearGradient>
              </defs>
              <path
                d="M0 34 L14 31 L25 32 L38 24 L50 27 L64 19 L78 22 L91 15 L104 19 L118 12 L132 18 L146 14 L160 23 L174 17 L188 22 L202 12 L216 18 L230 10 L244 16 L258 12 L270 20 L280 16 L280 46 L0 46 Z"
                fill="url(#telFill)"
              />
              <path
                d="M0 34 L14 31 L25 32 L38 24 L50 27 L64 19 L78 22 L91 15 L104 19 L118 12 L132 18 L146 14 L160 23 L174 17 L188 22 L202 12 L216 18 L230 10 L244 16 L258 12 L270 20 L280 16"
                fill="none" stroke={section.color} strokeWidth="1.2"
              />
            </svg>
            <span>CHANNEL INTEGRITY</span>
            <b>99.98%</b>
          </div>

          <div className="throttle-block">
            <div className="throttle-head">
              <span className="micro">THROTTLE QUADRANT</span>
              <strong>{Math.round(throttle * 100)}<small>%</small></strong>
            </div>
            <input
              className="throttle-input"
              type="range"
              min={0}
              max={100}
              value={Math.round(throttle * 100)}
              onChange={(e) => setThrottle(Number(e.target.value) / 100)}
              aria-label="Throttle quadrant position"
              style={{ ['--fill' as string]: `${throttle * 100}%` }}
            />
            <div className="throttle-scale" aria-hidden="true">
              <span>IDLE</span><span>DETENT 04</span><span>MAX</span>
            </div>
          </div>

          <button
            className={`audit-switch ${grayscale ? 'is-on' : ''}`}
            onClick={() => setGrayscale((v) => !v)}
            aria-pressed={grayscale}
          >
            <span className="switch"><i /></span>
            <span>
              <strong>Silhouette audit</strong>
              <small>Strip materials, judge geometry</small>
            </span>
          </button>

          <div className="tel-links">
            <button onClick={() => openDossier('geometry')}>Open dossier <span>↗</span></button>
            <button onClick={() => setCallouts((v) => !v)}>{callouts ? 'Hide' : 'Show'} callouts</button>
          </div>
        </aside>

        {callouts && !grayscale && (
          <div className="callouts" aria-hidden="true">
            <div className="callout" style={{ top: '11%', left: '61%' }}>
              <span className="callout-dot" /><span className="callout-line" />
              <div className="callout-copy"><strong>CANOPY HEADER</strong><small>7075-T6 · RMF MULLION &amp; EPDM SEAL</small></div>
            </div>
            <div className="callout flip" style={{ top: '54%', left: '47%' }}>
              <span className="callout-dot" /><span className="callout-line" />
              <div className="callout-copy"><strong>PRIMARY PFD</strong><small>CNC POCKET BEZEL · 15° MIP</small></div>
            </div>
          </div>
        )}

        <div className="scene-meta" aria-hidden="true">
          <span>LAT 51.64° N</span>
          <span>LON 000.00° E</span>
          <span>ATT +1.4° / −0.2°</span>
        </div>
      </main>

      <footer className="deck">
        <div className="deck-left">
          <div className="deck-id">
            <span className="deck-glyph">HX</span>
            <div>
              <strong>HX-9 / FLIGHT DECK</strong>
              <span>DESIGN STUDY · REV 05 · 2026</span>
            </div>
          </div>
          <p className="deck-note">
            Designed &amp; engineered by <b>Lê Quốc Khánh</b>
          </p>
        </div>

        <div className="key-arc-wrap">
          <div className="key-arc-label">
            <span>COMMAND KEYS</span>
            <span className="faint">ARC Ø {COMMAND_ARC.radius.toFixed(2)} M · OUTER COLUMN {COMMAND_ARC.outerColumn.toFixed(2)}</span>
          </div>
          <div className="key-arc" role="tablist" aria-label="Cockpit systems">
            {SECTIONS.map((s, i) => {
              const a = (KEY_ANGLES[i] * Math.PI) / 180;
              const x = Math.cos(a) * ARC_R;
              const y = KEY_CENTER_Y - Math.sin(a) * ARC_R;
              return (
                <button
                  key={s.id}
                  role="tab"
                  aria-selected={s.id === sectionId}
                  className={`key ${s.id === sectionId ? 'is-active' : ''}`}
                  style={{ transform: `translate(calc(-50% + ${x}px), ${y}px)` }}
                  onClick={() => setSectionId(s.id)}
                  title={`${s.title} — key ${i + 1}`}
                >
                  <span className="key-top">
                    <span className="key-num">{s.index}</span>
                    <span className="key-led" style={{ background: s.id === sectionId ? s.color : undefined }} />
                  </span>
                  <span className="key-label">{s.label}</span>
                  <span className="key-code">{s.code}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="deck-right">
          <div className="deck-cam">
            <span className="micro">CAMERA {activeView.index}</span>
            <strong>{VIEW_COPY[view].title}</strong>
            <span>{activeView.caption} · FOV {activeView.fov}°</span>
          </div>
          <button className="deck-audit" onClick={() => setGrayscale((v) => !v)}>
            {grayscale ? 'RESTORE MATERIALS' : 'AUDIT GEOMETRY'}
          </button>
        </div>
      </footer>

      <Dossier
        open={dossierOpen}
        active={dossierTab}
        onTab={setDossierTab}
        onClose={() => setDossierOpen(false)}
        section={sectionId}
      />
    </div>
  );
}
