import { useId } from 'react';
import { DOSSIER, SOURCES, type SectionId } from '../data/blueprint';

interface Props {
  open: boolean;
  active: string;
  onTab: (id: string) => void;
  onClose: () => void;
  section: SectionId;
}

function CrossSection() {
  return (
    <figure className="dossier-figure">
      <svg viewBox="0 0 420 208" role="img" aria-label="Cockpit longitudinal section showing canopy arch, glare shield, display plane, seat and floor">
        <defs>
          <linearGradient id="secFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#253b42" stopOpacity="0.95" />
            <stop offset="1" stopColor="#0b1417" stopOpacity="0.95" />
          </linearGradient>
        </defs>
        <g stroke="rgba(150,200,210,.22)" strokeWidth="0.6">
          {Array.from({ length: 13 }).map((_, i) => (
            <line key={`v${i}`} x1={i * 35} y1="0" x2={i * 35} y2="208" />
          ))}
          {Array.from({ length: 7 }).map((_, i) => (
            <line key={`h${i}`} x1="0" y1={i * 35} x2="420" y2={i * 35} />
          ))}
        </g>
        {/* pressure shell */}
        <path
          d="M54 176 L54 92 Q58 57 100 45 L205 30 L316 42 Q362 51 368 88 L368 176 Z"
          fill="url(#secFill)" stroke="#89b3c0" strokeWidth="1.2"
        />
        {/* canopy opening */}
        <path
          d="M96 56 Q197 24 334 55 L344 83 Q260 58 92 86 Z"
          fill="rgba(53,99,112,.22)" stroke="#8ad8e8" strokeWidth="0.8" strokeDasharray="3 3"
        />
        {/* arch C-section */}
        <path d="M92 86 L82 74 L96 49 L111 58 L101 78 Z" fill="#30454c" stroke="#bfd8df" strokeWidth="1" />
        <path d="M341 84 L329 67 L340 50 L354 62 L348 84 Z" fill="#30454c" stroke="#bfd8df" strokeWidth="1" />
        {/* dash and display plane */}
        <path d="M116 149 L118 118 L300 119 L318 149 Z" fill="#142227" stroke="#9dc4ce" strokeWidth="1" />
        <path d="M170 127 L264 127 L270 143 L164 143 Z" fill="rgba(125,230,255,.22)" stroke="#7de6ff" strokeWidth="1" />
        <line x1="192" y1="135" x2="246" y2="135" stroke="#7de6ff" strokeWidth="1" />
        <line x1="178" y1="139" x2="254" y2="139" stroke="rgba(125,230,255,.5)" strokeWidth="0.7" />
        {/* glareshield */}
        <path d="M114 111 Q217 96 316 111" fill="none" stroke="#c8d8dd" strokeWidth="2" />
        {/* seat */}
        <path d="M303 168 L300 116 Q300 103 287 104 L276 108 Q270 118 270 132 L268 145 L244 151 Q238 158 244 164 L278 165 L278 168 Z" fill="#1c2529" stroke="#8fabb4" strokeWidth="1" />
        <path d="M272 114 Q300 108 298 140 L281 145 Q269 130 272 114 Z" fill="#2b363b" stroke="#9ab7c0" strokeWidth="0.8" />
        {/* eye point */}
        <circle cx="236" cy="87" r="3.4" fill="#ffc16b" />
        <path d="M236 87 L204 112" stroke="rgba(255,193,107,.65)" strokeWidth="0.9" strokeDasharray="3 2" />
        <path d="M236 87 L321 109" stroke="rgba(255,193,107,.3)" strokeWidth="0.7" strokeDasharray="3 3" />
        {/* centre pedestal */}
        <path d="M194 149 L200 175 L240 175 L247 151 Z" fill="#202b30" stroke="#9ab7c0" strokeWidth="0.9" />
        <path d="M205 151 L222 137 L230 141 L216 155 Z" fill="#0e1518" stroke="#b5ccd3" strokeWidth="0.7" />
        {/* floor */}
        <line x1="54" y1="176" x2="368" y2="176" stroke="#adc5cc" strokeWidth="1.5" />
        <line x1="232" y1="176" x2="236" y2="168" stroke="rgba(210,230,235,.4)" strokeWidth="0.7" />
        {/* dimensions */}
        <g fill="#9fb9c1" fontFamily="JetBrains Mono, monospace" fontSize="6.2" letterSpacing="0.7">
          <text x="14" y="180">DECK DATUM</text>
          <text x="194" y="20">CANOPY ENVELOPE</text>
          <text x="263" y="80">DESIGN EYE</text>
          <text x="149" y="160">15° DISPLAY PLANE</text>
          <text x="338" y="169">SEAT RAIL</text>
          <text x="37" y="110">2.0 MM SKIN</text>
        </g>
        <g stroke="rgba(255,193,107,.55)" strokeWidth="0.6">
          <line x1="236" y1="87" x2="260" y2="87" />
          <line x1="260" y1="87" x2="260" y2="80" />
        </g>
      </svg>
      <figcaption>
        Longitudinal section, concept datum. Frame sizes and skin gauges are design assumptions,
        not type-certified dimensions.
      </figcaption>
    </figure>
  );
}

function ReachDiagram() {
  const id = useId();
  return (
    <figure className="dossier-figure">
      <svg viewBox="0 0 420 208" role="img" aria-label="Top view of the seated reach envelope and control grouping">
        <defs>
          <radialGradient id={id} cx="50%" cy="62%" r="56%">
            <stop offset="0" stopColor="#2c5059" stopOpacity="0.55" />
            <stop offset="0.72" stopColor="#152b31" stopOpacity="0.28" />
            <stop offset="1" stopColor="#060f12" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width="420" height="208" fill="url(#fixture)" opacity="0" />
        <g stroke="rgba(150,200,210,.2)" strokeWidth="0.6">
          {Array.from({ length: 10 }).map((_, i) => (
            <line key={i} x1={i * 46} y1="0" x2={i * 46} y2="208" />
          ))}
          {Array.from({ length: 5 }).map((_, i) => (
            <line key={`h${i}`} x1="0" y1={i * 46} x2="420" y2={i * 46} />
          ))}
        </g>
        <circle cx="210" cy="168" r="152" fill={`url(#${id})`} />
        <g fill="none" stroke="rgba(150,205,215,.5)">
          <path d="M70 168 A140 140 0 0 1 350 168" strokeDasharray="4 4" />
          <path d="M96 168 A114 114 0 0 1 324 168" />
          <path d="M130 168 A80 80 0 0 1 290 168" strokeDasharray="2 3" />
        </g>
        <g fill="#a8c3ca" fontFamily="JetBrains Mono, monospace" fontSize="6.2" letterSpacing="0.7">
          <text x="314" y="152">REACH 584</text>
          <text x="290" y="126">PRIMARY 390</text>
          <text x="252" y="104">SECONDARY 250</text>
        </g>
        {/* seated body */}
        <ellipse cx="210" cy="158" rx="30" ry="16" fill="#223338" stroke="#9db8c0" strokeWidth="0.9" />
        <path d="M192 140 Q210 126 228 140 L234 120 L186 120 Z" fill="#1b292d" stroke="#89a7b0" strokeWidth="0.8" />
        <circle cx="210" cy="111" r="10" fill="#2a3b40" stroke="#aec6cd" strokeWidth="0.9" />
        <path d="M196 129 Q176 140 164 151" fill="none" stroke="#aec6cd" strokeWidth="1.1" />
        <path d="M224 129 Q242 140 256 151" fill="none" stroke="#aec6cd" strokeWidth="1.1" />
        <circle cx="164" cy="151" r="3.2" fill="#7de6ff" />
        <circle cx="256" cy="151" r="3.2" fill="#7de6ff" />
        {/* controls */}
        <rect x="200" y="62" width="20" height="12" rx="2" fill="#2f454c" stroke="#9db8c0" strokeWidth="0.8" />
        <rect x="157" y="70" width="10" height="22" rx="2" fill="#2f454c" stroke="#9db8c0" strokeWidth="0.8" />
        <rect x="253" y="70" width="10" height="22" rx="2" fill="#2f454c" stroke="#9db8c0" strokeWidth="0.8" />
        <text x="148" y="60" fill="#ffc16b" fontFamily="JetBrains Mono, monospace" fontSize="6.2">PEDESTAL</text>
        <text x="277" y="66" fill="#9fb9c1" fontFamily="JetBrains Mono, monospace" fontSize="6.2">SIDE CONSOLE</text>
        <line x1="232" y1="84" x2="273" y2="70" stroke="rgba(200,225,232,.35)" strokeWidth="0.6" />
        <line x1="198" y1="56" x2="198" y2="44" stroke="rgba(255,193,107,.5)" strokeWidth="0.6" />
        <g fill="#c5dde2" fontFamily="JetBrains Mono, monospace" fontSize="6.2">
          <text x="12" y="198">TOP VIEW · SEATED OPERATOR · ARM REACH SHOWN FOR REFERENCE</text>
        </g>
      </svg>
      <figcaption>
        Control grouping follows task frequency and seated reach. The 584 mm figure is used as a
        design constraint, not a claimed anthropometric percentile.
      </figcaption>
    </figure>
  );
}

function MaterialSwatches() {
  const swatches = [
    { name: '7075-T6 CNC', detail: 'Cycloidal mill / Type III anodise', cls: 'swatch-al' },
    { name: 'CFRP 2×2 TWILL', detail: 'Autoclave monocoque / epoxy', cls: 'swatch-carbon' },
    { name: 'NOMEX RIPSTOP', detail: 'Segmented pads & MIL-W-4088 belt', cls: 'swatch-fabric' },
    { name: 'EPDM / SILICONE', detail: 'Compressed Z-rabbet bulb seal', cls: 'swatch-seal' },
    { name: 'Ti-6Al-4V', detail: 'Lightening trusses & hook latches', cls: 'swatch-ti' },
    { name: 'FUSED SILICA', detail: 'Beveled edge & dichroic HUD', cls: 'swatch-glass' },
  ];
  return (
    <div className="swatch-grid" role="list" aria-label="Material palette">
      {swatches.map((s) => (
        <div className="swatch" key={s.name} role="listitem">
          <span className={`swatch-chip ${s.cls}`} aria-hidden="true" />
          <strong>{s.name}</strong>
          <small>{s.detail}</small>
        </div>
      ))}
    </div>
  );
}

export function Dossier({ open, active, onTab, onClose, section }: Props) {
  const panel = DOSSIER.find((p) => p.id === active) ?? DOSSIER[0];
  return (
    <>
      <div className={`dossier-scrim ${open ? 'is-open' : ''}`} onClick={onClose} aria-hidden="true" />
      <aside className={`dossier ${open ? 'is-open' : ''}`} aria-hidden={!open} aria-label="Engineering dossier">
        <div className="dossier-top">
          <div>
            <p className="micro amber">AETHERWORKS / DOCUMENT 09–04</p>
            <h2>Engineering<br />dossier</h2>
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Close dossier">
            <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 4l12 12M16 4L4 16" /></svg>
          </button>
        </div>
        <div className="dossier-tabs" role="tablist" aria-label="Dossier sections">
          {DOSSIER.map((p) => (
            <button
              key={p.id}
              role="tab"
              aria-selected={p.id === panel.id}
              className={p.id === panel.id ? 'is-active' : ''}
              onClick={() => onTab(p.id)}
            >
              {p.label.split(' / ')[0]}
              <span>{p.label.split(' / ')[1]}</span>
            </button>
          ))}
        </div>
        <div className="dossier-body">
          <p className="micro">{panel.label} · HX-9 FLIGHT DECK</p>
          <h3>{panel.heading}</h3>
          <p className="dossier-lede">{panel.body}</p>
          {panel.id === 'geometry' && <CrossSection />}
          {panel.id === 'human' && <ReachDiagram />}
          {panel.id === 'materials' && <MaterialSwatches />}
          {panel.id === 'validation' && (
            <div className="test-matrix">
              {[
                ['Build / TypeScript', 'PASS'],
                ['Grey geometry review', '4 VIEWS'],
                ['Material + light pass', 'PASS'],
                ['Human-in-loop trial', 'NOT RUN'],
                ['Structural validation', 'NOT IN SCOPE'],
                ['GPU frame timing', 'NOT MEASURED'],
              ].map(([test, status]) => (
                <div key={test} className={status.includes('NOT') ? 'test is-open' : 'test'}>
                  <span>{test}</span>
                  <b>{status}</b>
                </div>
              ))}
            </div>
          )}
          <ol className="dossier-points">
            {panel.points.map((point, i) => (
              <li key={point.title}>
                <span className="pt-num">{String(i + 1).padStart(2, '0')}</span>
                <div>
                  <h4>{point.title}</h4>
                  <p>{point.detail}</p>
                </div>
              </li>
            ))}
          </ol>
          {panel.id === 'validation' && (
            <div className="sources">
              <p className="micro">References consulted</p>
              {SOURCES.map((s) => (
                <div className="source" key={s.n}>
                  <span>{s.n}</span>
                  <div><strong>{s.label}</strong><small>{s.meta}</small></div>
                </div>
              ))}
            </div>
          )}
          <div className="dossier-note">
            <span className="dot" />
            <p>
              Concept design study for interface research. Not flight hardware. No parts,
              dimensions or procedures here are qualified for operational use.
            </p>
          </div>
        </div>
        <div className="dossier-foot">
          <span>HX-9 / REV 05</span>
          <span>SECTION {section.toUpperCase()}</span>
          <span>2026</span>
        </div>
      </aside>
    </>
  );
}
