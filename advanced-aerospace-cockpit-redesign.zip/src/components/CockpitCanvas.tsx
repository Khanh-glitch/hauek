import { useEffect, useRef, useState } from 'react';
import type { CockpitSection, ViewId } from '../data/blueprint';
import { createCockpitEngine, type CockpitEngine } from '../cockpit/engine';

interface Props {
  section: CockpitSection;
  view: ViewId;
  throttle: number;
  grayscale: boolean;
  onError: () => void;
}

export function CockpitCanvas({ section, view, throttle, grayscale, onError }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<CockpitEngine | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let engine: CockpitEngine | null = null;
    try {
      engine = createCockpitEngine(canvas);
      engineRef.current = engine;
      setReady(true);
    } catch (err) {
      console.error('[HX-9] WebGL initialisation failed', err);
      onError();
    }
    const onFonts = () => engineRef.current?.refreshScreens();
    if (document.fonts?.ready) document.fonts.ready.then(onFonts).catch(() => undefined);
    return () => {
      setReady(false);
      engine?.dispose();
      engineRef.current = null;
    };
  }, [onError]);

  useEffect(() => {
    if (!ready) return;
    engineRef.current?.setView(view);
  }, [ready, view]);

  useEffect(() => {
    if (!ready) return;
    engineRef.current?.setSection(section);
  }, [ready, section]);

  useEffect(() => {
    if (!ready) return;
    engineRef.current?.setThrottle(throttle);
  }, [ready, throttle]);

  useEffect(() => {
    if (!ready) return;
    engineRef.current?.setGrayscale(grayscale);
  }, [ready, grayscale]);

  return (
    <canvas
      ref={canvasRef}
      className="cockpit-canvas"
      aria-label="Interactive three-dimensional reconstruction of the HX-9 command module cockpit"
    />
  );
}
