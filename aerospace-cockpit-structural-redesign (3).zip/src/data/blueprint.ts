export type SectionId = 'flight' | 'power' | 'life' | 'orbit' | 'comms' | 'log';

export interface CockpitSection {
  id: SectionId;
  index: string;
  code: string;
  label: string;
  labelVi: string;
  title: string;
  kicker: string;
  description: string;
  stats: { k: string; v: string; unit?: string }[];
  color: string;
  screen: {
    heading: string;
    sub: string;
    primary: string;
    unit: string;
    rows: { label: string; value: string; bar: number }[];
    readout: string;
  };
}

export const SECTIONS: CockpitSection[] = [
  {
    id: 'flight',
    index: '01',
    code: 'FLT',
    label: 'Flight',
    labelVi: 'Bay',
    title: 'Primary flight',
    kicker: 'Guidance / control law',
    description:
      'Reversionary fly-by-wire with a three-lane command path. The primary display sits on the 15° panel plane, inside a 30° cone from the design eye point.',
    stats: [
      { k: 'Velocity', v: '7 812', unit: 'm/s' },
      { k: 'Pitch', v: '+1.4', unit: '°' },
      { k: 'Bank', v: '−0.2', unit: '°' },
    ],
    color: '#7de6ff',
    screen: {
      heading: 'PRIMARY FLIGHT DISPLAY',
      sub: 'LANE A / NOMINAL',
      primary: '7 812',
      unit: 'M · S⁻¹',
      rows: [
        { label: 'ALT', value: '4 012.6 KM', bar: 0.62 },
        { label: 'VRT SPD', value: '+ 2.4 M/S', bar: 0.41 },
        { label: 'ATT', value: '+1.4 / −0.2', bar: 0.5 },
        { label: 'G-LOAD', value: '1.00 G', bar: 0.28 },
      ],
      readout: 'GUIDANCE · VECTOR 7B · CORRIDOR NOMINAL',
    },
  },
  {
    id: 'power',
    index: '02',
    code: 'PWR',
    label: 'Power',
    labelVi: 'Nguồn',
    title: 'Power architecture',
    kicker: 'Generation / distribution',
    description:
      'Twin high-temperature reactors feed a 540 V DC primary bus through solid-state breakers. Both buses remain independent until the cross-tie is armed.',
    stats: [
      { k: 'Bus A', v: '98.2', unit: '%' },
      { k: 'Bus B', v: '96.7', unit: '%' },
      { k: 'Reserve', v: '31.4', unit: 'kWh' },
    ],
    color: '#ffc16b',
    screen: {
      heading: 'ELECTRICAL POWER',
      sub: 'BUS A / BUS B ISOLATED',
      primary: '184.6',
      unit: 'KWE · TOTAL',
      rows: [
        { label: 'REACTOR A', value: '96.4 %', bar: 0.96 },
        { label: 'REACTOR B', value: '93.1 %', bar: 0.93 },
        { label: 'BATTERY', value: '31.4 KWH', bar: 0.68 },
        { label: 'THERMAL', value: '284 K', bar: 0.44 },
      ],
      readout: 'CROSS-TIE SAFED · LOAD SHED ARM · 0 FAULTS',
    },
  },
  {
    id: 'life',
    index: '03',
    code: 'LSS',
    label: 'Life',
    labelVi: 'Sự sống',
    title: 'Life support',
    kicker: 'Atmosphere / thermal',
    description:
      'A regenerable two-bed CO₂ scrubber and humidity condenser hold a 21 % O₂ / 79 % N₂ atmosphere at 101.3 kPa. Crew interfaces sit outside the reach-critical envelope.',
    stats: [
      { k: 'Cabin', v: '101.3', unit: 'kPa' },
      { k: 'O₂', v: '20.9', unit: '%' },
      { k: 'ΔT', v: '21.4', unit: '°C' },
    ],
    color: '#8ff0c3',
    screen: {
      heading: 'ENVIRONMENTAL CONTROL',
      sub: 'CREW 02 / NOMINAL',
      primary: '101.3',
      unit: 'KPA · CABIN',
      rows: [
        { label: 'O₂ PART', value: '20.9 %', bar: 0.84 },
        { label: 'CO₂', value: '0.31 %', bar: 0.22 },
        { label: 'HUMIDITY', value: '42 %', bar: 0.42 },
        { label: 'TEMP', value: '21.4 °C', bar: 0.54 },
      ],
      readout: 'SCRUBBER B ACTIVE · CONDENSATE 0.7 L · NO ALARMS',
    },
  },
  {
    id: 'orbit',
    index: '04',
    code: 'ORB',
    label: 'Orbit',
    labelVi: 'Quỹ đạo',
    title: 'Orbital track',
    kicker: 'Navigation / trajectory',
    description:
      'A three-impulse transfer toward the servicing shell. Ground track and closure vector are resolved from a dual GNSS / star-tracker solution with a cold-gas trim budget.',
    stats: [
      { k: 'Altitude', v: '412.6', unit: 'km' },
      { k: 'Inclination', v: '51.6', unit: '°' },
      { k: 'Range', v: '2 418', unit: 'm' },
    ],
    color: '#b9a8ff',
    screen: {
      heading: 'ORBITAL NAVIGATION',
      sub: 'DUAL STAR TRACKER / FIX 0913',
      primary: '412.6',
      unit: 'KM · ALTITUDE',
      rows: [
        { label: 'INC', value: '51.64 °', bar: 0.51 },
        { label: 'ECC', value: '0.0004', bar: 0.12 },
        { label: 'CLOSURE', value: '2.4 M/S', bar: 0.33 },
        { label: 'ΔV', value: '18.2 M/S', bar: 0.7 },
      ],
      readout: 'BURN 02 · T−00:14:22 · CORRIDOR NOMINAL',
    },
  },
  {
    id: 'comms',
    index: '05',
    code: 'COM',
    label: 'Comms',
    labelVi: 'Liên lạc',
    title: 'Comms & telemetry',
    kicker: 'Link / data handling',
    description:
      'Dual optical terminals with a Ka-band fallback. Critical command frames are authenticated and repeated on both paths; the backup bus is deliberately physically separated.',
    stats: [
      { k: 'Optical', v: '2.4', unit: 'Gb/s' },
      { k: 'Latency', v: '38', unit: 'ms' },
      { k: 'Packet', v: '0', unit: 'loss' },
    ],
    color: '#87d0ff',
    screen: {
      heading: 'COMMUNICATIONS',
      sub: 'OPTICAL A / KA-BAND STANDBY',
      primary: '2.4',
      unit: 'GBPS · DOWNLINK',
      rows: [
        { label: 'LINK A', value: '99.9 %', bar: 0.99 },
        { label: 'LINK B', value: 'STANDBY', bar: 0.32 },
        { label: 'LATENCY', value: '38 MS', bar: 0.38 },
        { label: 'BUFFER', value: '18 %', bar: 0.18 },
      ],
      readout: 'AUTH OK · 0 LOST FRAMES · RECORDER 74 % FREE',
    },
  },
  {
    id: 'log',
    index: '06',
    code: 'LOG',
    label: 'Log',
    labelVi: 'Nhật ký',
    title: 'Mission log',
    kicker: 'Events / configuration',
    description:
      'A configuration record is written to the hardened flight log whenever a control position, bus state or hatch seal changes. Entries are time-stamped at source.',
    stats: [
      { k: 'Entries', v: '1 248', unit: '' },
      { k: 'Uptime', v: '219', unit: 'd' },
      { k: 'Faults', v: '03', unit: 'open' },
    ],
    color: '#ffd3a0',
    screen: {
      heading: 'SHIPBOARD LOG',
      sub: 'ARCHIVE 118 / LIVE APPEND',
      primary: 'T−00:14',
      unit: 'TO NEXT MANOEUVRE',
      rows: [
        { label: '09:42', value: 'CANOPY LATCH / SEALED', bar: 0.92 },
        { label: '09:38', value: 'BUS A CROSS-TIE SAFED', bar: 0.72 },
        { label: '09:21', value: 'O₂ VALVE B / OPEN', bar: 0.5 },
        { label: '08:57', value: 'STAR TRACKER / LOCK', bar: 0.38 },
      ],
      readout: 'LOG INTEGRITY OK · CRC 32 PASSED · NO WRITE ERRORS',
    },
  },
];

export type ViewId = 'pilot' | 'command' | 'overhead' | 'detail';

export interface StudyView {
  id: ViewId;
  index: string;
  label: string;
  caption: string;
  fov: number;
  position: [number, number, number];
  target: [number, number, number];
}

export const STUDY_VIEWS: StudyView[] = [
  {
    id: 'pilot',
    index: 'A',
    label: 'Design eye',
    caption: 'Eye point · 1.08 m over deck',
    fov: 58,
    position: [0, 0.115, 0.56],
    target: [0, -0.075, -1.25],
  },
  {
    id: 'command',
    index: 'B',
    label: 'Command reach',
    caption: 'Lateral 470 mm · panel 15°',
    fov: 55,
    position: [0.4, 0.07, 0.55],
    target: [-0.06, -0.09, -1.18],
  },
  {
    id: 'overhead',
    index: 'C',
    label: 'Overhead',
    caption: 'Seat, pedestal and rail study',
    fov: 62,
    position: [0.58, 0.56, 1.2],
    target: [0, -0.36, -0.8],
  },
  {
    id: 'detail',
    index: 'D',
    label: 'Console macro',
    caption: 'Materials at 280 mm',
    fov: 44,
    position: [0.05, 0.02, -0.12],
    target: [-0.44, -0.33, -0.95],
  },
];

export interface DossierPanel {
  id: string;
  label: string;
  heading: string;
  body: string;
  points: { title: string; detail: string }[];
}

export const DOSSIER: DossierPanel[] = [
  {
    id: 'geometry',
    label: '01 / Geometry',
    heading: 'Structure before surface',
    body:
      'The cabin is assembled from extruded C- and Z-sections, lofted skin panels, swept tubes and lathed fittings. Repeated hardware follows a frame layout rather than being scattered as decoration.',
    points: [
      {
        title: 'Canopy arch',
        detail:
          'Swept 7075-T6 C-section with a closed-cell silicone seal retained in a Z-channel. The arch carries canopy loads into the two forward frames.',
      },
      {
        title: 'Panels',
        detail:
          'Skin panels are 2.0 mm aluminium with joggled edges and a 12 mm flange; fasteners are placed at 30–40 mm pitch on the flange centre-line.',
      },
      {
        title: 'Dash',
        detail:
          'A bonded monocoque with a rolled top lip and a separate glare shield. The display plane is tipped 15° toward the design eye point.',
      },
    ],
  },
  {
    id: 'human',
    label: '02 / Human',
    heading: 'A body sets the datum',
    body:
      'Primary controls sit inside the seated functional reach envelope. The design eye point is the single reference for display distance, canopy aperture and panel tilt; secondary switches are grouped by task, not by symmetry.',
    points: [
      {
        title: 'Design eye point',
        detail:
          'A fixed eye reference at 1.08 m above the deck. The primary display falls 12–18° below the horizontal sight line, within the recommended downward viewing range.',
      },
      {
        title: 'Reach',
        detail:
          'Flight-critical controls are kept within a 584 mm functional reach arc. The throttle quadrant is between the knees; the guard rails protect inadvertent actuation.',
      },
      {
        title: 'Vision',
        detail:
          'The canopy frame retains an unobstructed upper field. A-pillars are pushed outboard so the forward field is framed, not interrupted, by structure.',
      },
    ],
  },
  {
    id: 'materials',
    label: '03 / Materials',
    heading: 'Concessions, not decoration',
    body:
      'Materials are selected for wear behaviour and inspectability. Anodised flight hardware, bead-blasted titanium, carbon composite, silicone seals and wool-blend upholstery meet at deliberate, replaceable interfaces.',
    points: [
      {
        title: 'Machined aluminium',
        detail:
          'Bead-blasted and hard-anodised. Edges are broken 0.3 mm; wear shows first on radii and around fastener heads, never as a uniform gloss.',
      },
      {
        title: 'Carbon monocoque',
        detail:
          'Visible 2×2 twill under clear coat on the seat shell, with an opaque backing. Fastener collars isolate the shell from the aluminium seat rails.',
      },
      {
        title: 'Soft goods',
        detail:
          'Wool-blend seat upholstery, high-temperature silicone gaskets and Hytrel-cored cable. Surface normal maps give the weave a scale that stays believable at 280 mm.',
      },
    ],
  },
  {
    id: 'validation',
    label: '04 / Method',
    heading: 'What has been tested',
    body:
      'This is a rendered design study, not a certified vehicle. The cabin was reviewed as a grey, untextured model from the design eye, an oblique angle, overhead and a macro console view. Raster review is a geometry aid, not a substitute for WebGL inspection or physical mock-up.',
    points: [
      {
        title: 'Grey audit',
        detail:
          'All decorative materials, emissives, starfield and planet are removed. The camera study remains useful only if structure and depth read without lighting tricks.',
      },
      {
        title: 'Reference documents',
        detail:
          'MIL-STD-1472H (Human Engineering Design Criteria), NASA-STD-3001 Vol. 2, NASA NTRS crewed cockpit studies; public imagery of Crew Dragon, Soyuz, Boeing 737NG and A-10C.',
      },
      {
        title: 'Open limits',
        detail:
          'No anthropometric survey, no pilot-in-the-loop evaluation, no GPU frame-time measurement, no structural validation. Sources inform the study; they are not a compliance claim.',
      },
    ],
  },
];

export const SOURCES = [
  { n: '01', label: 'MIL-STD-1472H · Human Engineering Design Criteria for Military Systems', meta: 'US DoD, 2020' },
  { n: '02', label: 'NASA-STD-3001 Vol. 2 · Human Factors, Habitability & Environmental Health', meta: 'NASA, current revision' },
  { n: '03', label: 'NASA Technical Reports Server · crewed spacecraft cockpit and display studies', meta: 'ntrs.nasa.gov' },
  { n: '04', label: 'Crew Dragon interior photography and NASA Commercial Crew releases', meta: 'Public reference' },
  { n: '05', label: 'Boeing 737NG flight deck · control-display grouping and eye reference', meta: 'Public reference' },
  { n: '06', label: 'A-10C cockpit and Soyuz descent module imagery · switch guarding and reach', meta: 'Public reference' },
];

export const VIEW_COPY: Record<ViewId, { title: string; body: string }> = {
  pilot: {
    title: 'Design eye',
    body: 'Seated datum: primary display in the lower 15° of sight, canopy aperture held open above.',
  },
  command: {
    title: 'Command reach',
    body: 'Throttle and cursor control within the seated reach arc; side consoles canted to the wrist.',
  },
  overhead: {
    title: 'Overhead study',
    body: 'Seat shell, harness paths, pedestal and floor rails read as one load-bearing assembly.',
  },
  detail: {
    title: 'Console macro',
    body: 'Machined bezel, button legend, fastener pitch and dust shadow at close inspection.',
  },
};
