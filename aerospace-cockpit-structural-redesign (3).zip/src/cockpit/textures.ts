import * as THREE from 'three';
import type { CockpitSection, SectionId } from '../data/blueprint';

const TAU = Math.PI * 2;

export function makeCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d');
  if (!ctx) throw new Error('2D canvas unavailable');
  return [c, ctx];
}

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export function textureFromCanvas(canvas: HTMLCanvasElement, repeat = 1, srgb = true): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.anisotropy = 8;
  if (srgb) tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/* ── micro-surface maps ─────────────────────────────────────────────────────
   Procedural roughness/bump maps. These are deliberately low-contrast: at
   close range they should read as tool marks and weave, never as a pattern. */

export function brushedMetalMap(seed = 3): THREE.CanvasTexture {
  const [c, x] = makeCanvas(512, 512);
  x.fillStyle = '#8a8a8a';
  x.fillRect(0, 0, 512, 512);
  const r = rng(seed);
  for (let i = 0; i < 720; i++) {
    const y = r() * 512;
    const len = 60 + r() * 430;
    const start = r() * 512;
    const v = Math.floor(104 + r() * 44);
    x.strokeStyle = `rgba(${v},${v},${v},${0.1 + r() * 0.18})`;
    x.lineWidth = 0.5 + r() * 1.25;
    x.beginPath();
    x.moveTo(start, y);
    x.lineTo(start + len, y + (r() - 0.5) * 1.4);
    x.stroke();
  }
  for (let i = 0; i < 14; i++) {
    x.strokeStyle = `rgba(40,40,40,${0.05 + r() * 0.1})`;
    x.lineWidth = 0.7;
    x.beginPath();
    const y = r() * 512;
    x.moveTo(0, y);
    x.lineTo(512, y + (r() - 0.5) * 8);
    x.stroke();
  }
  return textureFromCanvas(c, 2, false);
}

export function weaveMap(carbon = true): THREE.CanvasTexture {
  const [c, x] = makeCanvas(256, 256);
  x.fillStyle = carbon ? '#5d5d5d' : '#777777';
  x.fillRect(0, 0, 256, 256);
  const cell = 16;
  for (let row = 0; row < 16; row++) {
    for (let col = 0; col < 16; col++) {
      const over = (row + col) % 2 === 0;
      const g = carbon ? (over ? 132 : 78) : over ? 150 : 116;
      x.fillStyle = `rgb(${g},${g},${g})`;
      x.fillRect(col * cell + 1, row * cell + 1, cell - 2, cell - 2);
      x.strokeStyle = `rgba(0,0,0,0.22)`;
      x.lineWidth = 1;
      for (let k = 3; k < cell - 2; k += 3) {
        x.beginPath();
        if (over) {
          x.moveTo(col * cell + k, row * cell + 1);
          x.lineTo(col * cell + k, row * cell + cell - 1);
        } else {
          x.moveTo(col * cell + 1, row * cell + k);
          x.lineTo(col * cell + cell - 1, row * cell + k);
        }
        x.stroke();
      }
    }
  }
  return textureFromCanvas(c, carbon ? 7 : 11, false);
}

export function leatherMap(): THREE.CanvasTexture {
  const [c, x] = makeCanvas(256, 256);
  x.fillStyle = '#8b8b8b';
  x.fillRect(0, 0, 256, 256);
  const r = rng(88);
  for (let i = 0; i < 2600; i++) {
    const v = Math.floor(90 + r() * 90);
    x.fillStyle = `rgba(${v},${v},${v},${0.18 + r() * 0.2})`;
    x.beginPath();
    x.arc(r() * 256, r() * 256, 0.4 + r() * 1.5, 0, TAU);
    x.fill();
  }
  for (let i = 0; i < 18; i++) {
    x.strokeStyle = `rgba(50,50,50,0.16)`;
    x.beginPath();
    let px = r() * 256;
    let py = r() * 256;
    x.moveTo(px, py);
    for (let k = 0; k < 6; k++) {
      px += (r() - 0.5) * 22;
      py += (r() - 0.5) * 22;
      x.lineTo(px, py);
    }
    x.stroke();
  }
  return textureFromCanvas(c, 5, false);
}

export function treadMap(): THREE.CanvasTexture {
  const [c, x] = makeCanvas(256, 256);
  x.fillStyle = '#777';
  x.fillRect(0, 0, 256, 256);
  x.strokeStyle = '#b9b9b9';
  x.lineWidth = 8;
  for (let i = -256; i < 512; i += 42) {
    x.beginPath();
    x.moveTo(i, 0);
    x.lineTo(i + 120, 256);
    x.stroke();
    x.beginPath();
    x.moveTo(i + 120, 0);
    x.lineTo(i, 256);
    x.stroke();
  }
  x.fillStyle = 'rgba(0,0,0,.24)';
  for (let i = 0; i < 400; i++) {
    x.fillRect(Math.random() * 256, Math.random() * 256, 1.5, 1.5);
  }
  return textureFromCanvas(c, 6, false);
}

/* ── decals ────────────────────────────────────────────────────────────────── */

export function labelTexture(
  text: string,
  sub = '',
  color = '#c9d8de',
  width = 512,
  height = 128,
): THREE.CanvasTexture {
  const [c, x] = makeCanvas(width, height);
  x.clearRect(0, 0, width, height);
  x.fillStyle = color;
  x.font = `600 ${Math.round(height * 0.3)}px "JetBrains Mono", monospace`;
  x.textBaseline = 'middle';
  x.fillText(text, 18, sub ? height * 0.37 : height * 0.52);
  if (sub) {
    x.fillStyle = 'rgba(200,218,224,.58)';
    x.font = `500 ${Math.round(height * 0.18)}px "JetBrains Mono", monospace`;
    x.fillText(sub, 18, height * 0.72);
  }
  x.strokeStyle = 'rgba(210,226,232,.32)';
  x.lineWidth = 2;
  x.strokeRect(2, 2, width - 4, height - 4);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

export function placardTexture(
  lines: string[],
  accent = '#ffc16b',
  width = 256,
  height = 128,
): THREE.CanvasTexture {
  const [c, x] = makeCanvas(width, height);
  x.fillStyle = 'rgba(12,16,18,.92)';
  x.fillRect(0, 0, width, height);
  x.strokeStyle = 'rgba(210,226,232,.28)';
  x.lineWidth = 3;
  x.strokeRect(5, 5, width - 10, height - 10);
  x.fillStyle = accent;
  x.fillRect(14, 16, 8, height - 32);
  x.fillStyle = '#d8e3e6';
  x.font = `600 ${lines.length > 2 ? 20 : 24}px "JetBrains Mono", monospace`;
  lines.forEach((l, i) => x.fillText(l, 34, 38 + i * 25));
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

/* ── environment ───────────────────────────────────────────────────────────── */

export function environmentTexture(): THREE.CanvasTexture {
  const [c, x] = makeCanvas(1024, 512);
  const sky = x.createLinearGradient(0, 0, 0, 512);
  sky.addColorStop(0, '#0a1620');
  sky.addColorStop(0.42, '#101c24');
  sky.addColorStop(0.6, '#1a2024');
  sky.addColorStop(1, '#030507');
  x.fillStyle = sky;
  x.fillRect(0, 0, 1024, 512);

  const warm = x.createRadialGradient(250, 160, 4, 250, 160, 290);
  warm.addColorStop(0, 'rgba(255,226,186,1)');
  warm.addColorStop(0.06, 'rgba(255,189,118,.8)');
  warm.addColorStop(0.32, 'rgba(121,93,61,.22)');
  warm.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = warm;
  x.fillRect(0, 0, 1024, 512);

  const cool = x.createRadialGradient(800, 250, 8, 800, 250, 340);
  cool.addColorStop(0, 'rgba(138,225,255,.85)');
  cool.addColorStop(0.15, 'rgba(79,155,191,.3)');
  cool.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = cool;
  x.fillRect(0, 0, 1024, 512);

  const under = x.createLinearGradient(0, 370, 0, 512);
  under.addColorStop(0, 'rgba(8,12,15,0)');
  under.addColorStop(1, 'rgba(2,4,6,1)');
  x.fillStyle = under;
  x.fillRect(0, 350, 1024, 162);

  x.strokeStyle = 'rgba(190,228,240,.07)';
  x.lineWidth = 2;
  for (let i = 0; i < 14; i++) {
    x.beginPath();
    x.moveTo(0, 80 + i * 23);
    x.lineTo(1024, 50 + i * 26);
    x.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.mapping = THREE.EquirectangularReflectionMapping;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/* ── space backdrop pieces ─────────────────────────────────────────────────── */

export function nebulaTexture(seed: number, hue = 196): THREE.CanvasTexture {
  const [c, x] = makeCanvas(512, 512);
  const r = rng(seed);
  x.clearRect(0, 0, 512, 512);
  for (let i = 0; i < 70; i++) {
    const cx = r() * 512;
    const cy = r() * 512;
    const rad = 30 + r() * 190;
    const g = x.createRadialGradient(cx, cy, 1, cx, cy, rad);
    const light = 40 + r() * 50;
    g.addColorStop(0, `rgba(${light + 30},${light + 55},${light + 75},${0.014 + r() * 0.035})`);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = g;
    x.beginPath();
    x.arc(cx, cy, rad, 0, TAU);
    x.fill();
  }
  for (let i = 0; i < 1400; i++) {
    const v = 130 + r() * 125;
    x.fillStyle = `rgba(${v},${v},${Math.min(255, v + 14)},${0.16 + r() * 0.7})`;
    const s = r() < 0.92 ? 1 : 1.8;
    x.fillRect(r() * 512, r() * 512, s, s);
  }
  x.globalCompositeOperation = 'lighter';
  const band = x.createLinearGradient(0, 180, 512, 360);
  band.addColorStop(0, 'rgba(0,0,0,0)');
  band.addColorStop(0.45, `hsla(${hue}, 60%, 60%, .05)`);
  band.addColorStop(0.7, 'rgba(0,0,0,0)');
  x.fillStyle = band;
  x.fillRect(0, 0, 512, 512);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function planetTexture(): THREE.CanvasTexture {
  const [c, x] = makeCanvas(1024, 512);
  const r = rng(731);
  const ocean = x.createLinearGradient(0, 0, 0, 512);
  ocean.addColorStop(0, '#050d12');
  ocean.addColorStop(0.5, '#081a23');
  ocean.addColorStop(1, '#050e14');
  x.fillStyle = ocean;
  x.fillRect(0, 0, 1024, 512);

  for (let i = 0; i < 22; i++) {
    const cx = r() * 1024;
    const cy = 80 + r() * 360;
    const rx = 40 + r() * 160;
    const ry = 18 + r() * 80;
    const g = x.createRadialGradient(cx, cy, 2, cx, cy, rx);
    const green = r() > 0.80;
    g.addColorStop(0, green ? 'rgba(38,57,46,.62)' : 'rgba(22,40,47,.62)');
    g.addColorStop(0.6, green ? 'rgba(28,44,37,.34)' : 'rgba(18,33,39,.34)');
    g.addColorStop(1, 'rgba(10,22,27,0)');
    x.save();
    x.translate(cx, cy);
    x.rotate(r() * TAU);
    x.scale(1, ry / rx);
    x.fillStyle = g;
    x.beginPath();
    x.arc(0, 0, rx, 0, TAU);
    x.fill();
    x.restore();
  }
  // Polar caps, cloud streaks
  x.fillStyle = 'rgba(200,222,228,.34)';
  x.fillRect(0, 0, 1024, 24);
  x.fillRect(0, 492, 1024, 20);
  for (let i = 0; i < 46; i++) {
    x.strokeStyle = `rgba(214,235,240,${0.018 + r() * 0.05})`;
    x.lineWidth = 2 + r() * 11;
    x.beginPath();
    const sy = 50 + r() * 410;
    x.moveTo(-20, sy);
    x.bezierCurveTo(280, sy + (r() - 0.5) * 40, 640, sy + (r() - 0.5) * 55, 1044, sy + (r() - 0.5) * 25);
    x.stroke();
  }
  for (let i = 0; i < 210; i++) {
    const cy = 20 + r() * 470;
    x.strokeStyle = `rgba(200,222,228,${0.012 + r() * 0.035})`;
    x.lineWidth = 0.5 + r() * 1.7;
    x.beginPath();
    x.moveTo(0, cy);
    x.bezierCurveTo(300, cy + (r() - 0.5) * 16, 700, cy + (r() - 0.5) * 22, 1024, cy + (r() - 0.5) * 10);
    x.stroke();
  }
  const shade = x.createLinearGradient(0, 0, 1024, 0);
  shade.addColorStop(0, 'rgba(2,7,10,.62)');
  shade.addColorStop(0.32, 'rgba(2,7,10,.05)');
  shade.addColorStop(0.62, 'rgba(2,7,10,.02)');
  shade.addColorStop(1, 'rgba(2,7,10,.82)');
  x.fillStyle = shade;
  x.fillRect(0, 0, 1024, 512);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = THREE.RepeatWrapping;
  t.anisotropy = 8;
  return t;
}

/* ── primary display ───────────────────────────────────────────────────────── */

const PALETTE: Record<SectionId, { main: string; dim: string }> = {
  flight: { main: '#7de6ff', dim: '#2a778c' },
  power: { main: '#ffc16b', dim: '#8a5f2c' },
  life: { main: '#8ff0c3', dim: '#327a5f' },
  orbit: { main: '#b9a8ff', dim: '#5b4f96' },
  comms: { main: '#87d0ff', dim: '#2e688a' },
  log: { main: '#ffd3a0', dim: '#856644' },
};

function grid(ctx: CanvasRenderingContext2D, w: number, h: number, color: string) {
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  for (let i = 0; i < w; i += 32) {
    ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, h); ctx.stroke();
  }
  for (let i = 0; i < h; i += 32) {
    ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(w, i); ctx.stroke();
  }
}

function attitude(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, main: string) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, TAU);
  ctx.clip();
  ctx.fillStyle = 'rgba(10,44,57,.82)';
  ctx.fillRect(cx - r, cy - r, r * 2, r);
  ctx.fillStyle = 'rgba(24,19,10,.82)';
  ctx.fillRect(cx - r, cy, r * 2, r);
  ctx.strokeStyle = main;
  ctx.lineWidth = 2;
  for (let i = -4; i <= 4; i++) {
    if (!i) continue;
    const y = cy + i * 18;
    const wid = i % 2 === 0 ? 38 : 22;
    ctx.beginPath(); ctx.moveTo(cx - wid, y); ctx.lineTo(cx + wid, y); ctx.stroke();
  }
  ctx.strokeStyle = 'rgba(255,255,255,.9)';
  ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(cx - r, cy); ctx.lineTo(cx + r, cy); ctx.stroke();
  ctx.restore();
  ctx.strokeStyle = main;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, TAU);
  ctx.stroke();
  ctx.lineWidth = 2;
  for (let i = 0; i < 48; i++) {
    const a = (i / 48) * TAU;
    const l = i % 4 === 0 ? 12 : 6;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * (r + 2), cy + Math.sin(a) * (r + 2));
    ctx.lineTo(cx + Math.cos(a) * (r + 2 + l), cy + Math.sin(a) * (r + 2 + l));
    ctx.stroke();
  }
  ctx.fillStyle = main;
  ctx.beginPath();
  ctx.moveTo(cx - 17, cy); ctx.lineTo(cx - 5, cy - 9); ctx.lineTo(cx - 5, cy + 9); ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(cx + 17, cy); ctx.lineTo(cx + 5, cy - 9); ctx.lineTo(cx + 5, cy + 9); ctx.closePath(); ctx.fill();
  ctx.fillRect(cx - 4, cy - 4, 8, 8);
  ctx.strokeStyle = 'rgba(255,255,255,.6)';
  ctx.beginPath();
  ctx.moveTo(cx, cy - 12); ctx.lineTo(cx, cy - 3);
  ctx.moveTo(cx, cy + 3); ctx.lineTo(cx, cy + 12);
  ctx.stroke();
}

export function paintScreen(canvas: HTMLCanvasElement, section: CockpitSection, throttle = 0.62): void {
  const w = canvas.width;
  const h = canvas.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const p = PALETTE[section.id];
  const s = section.screen;

  const bg = ctx.createLinearGradient(0, 0, 0, h);
  bg.addColorStop(0, '#071b22');
  bg.addColorStop(0.55, '#041116');
  bg.addColorStop(1, '#020a0e');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  ctx.save();
  ctx.globalAlpha = 0.18;
  grid(ctx, w, h, p.dim);
  ctx.restore();

  const glow = ctx.createRadialGradient(w * 0.5, h * 0.5, 10, w * 0.5, h * 0.5, w * 0.7);
  glow.addColorStop(0, 'rgba(100,200,220,.055)');
  glow.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, w, h);

  ctx.fillStyle = 'rgba(2,8,11,.85)';
  ctx.fillRect(0, 0, w, 64);
  ctx.fillStyle = p.main;
  ctx.font = '600 22px "Chakra Petch", sans-serif';
  ctx.fillText(s.heading, 36, 40);
  ctx.font = '500 14px "JetBrains Mono", monospace';
  ctx.fillStyle = 'rgba(208,228,234,.62)';
  ctx.fillText(s.sub, w - 330, 39);
  ctx.fillStyle = p.main;
  ctx.fillRect(0, 63, w, 2);
  ctx.fillRect(36, 14, 6, 34);

  const cx = w * 0.44;
  const cy = h * 0.58;
  if (section.id === 'flight') {
    attitude(ctx, cx, cy, h * 0.27, p.main);
    // speed and altitude tapes
    ctx.font = '500 17px "JetBrains Mono", monospace';
    for (const [bx, label] of [
      [70, 'SPD'],
      [w - 70, 'ALT'],
    ] as [number, string][]) {
      ctx.strokeStyle = 'rgba(190,225,232,.35)';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(bx, 110); ctx.lineTo(bx, h - 86); ctx.stroke();
      ctx.fillStyle = 'rgba(200,228,234,.6)';
      ctx.fillText(label, bx - 18, 100);
      for (let i = 0; i < 11; i++) {
        const y = 130 + i * 28;
        ctx.strokeStyle = i === 5 ? p.main : 'rgba(160,206,218,.4)';
        ctx.beginPath();
        ctx.moveTo(bx - (i === 5 ? 26 : 12), y);
        ctx.lineTo(bx, y);
        ctx.stroke();
        if (i % 2 === 0) {
          ctx.fillStyle = 'rgba(210,236,240,.72)';
          ctx.font = '500 14px "JetBrains Mono", monospace';
          ctx.fillText(String(label === 'SPD' ? 7780 + i * 4 : 397 + i), bx + 9, y + 5);
        }
      }
    }
    ctx.fillStyle = p.main;
    ctx.fillRect(cx - 92, 112, 184, 30);
    ctx.fillStyle = '#031317';
    ctx.font = '700 18px "JetBrains Mono", monospace';
    ctx.fillText('AP / AUTO', cx - 40, 133);
    ctx.fillStyle = 'rgba(170,215,225,.7)';
    ctx.font = '500 14px "JetBrains Mono", monospace';
    ctx.fillText('HDG 042   VS +02.4', cx - 92, h - 98);
  } else if (section.id === 'orbit') {
    const rr = h * 0.3;
    ctx.strokeStyle = 'rgba(140,220,240,.3)';
    ctx.beginPath(); ctx.arc(cx, cy, rr, 0, TAU); ctx.stroke();
    ctx.strokeStyle = p.main;
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(cx, cy, rr, -1.3, 1.1); ctx.stroke();
    const px = cx + Math.cos(0.4) * rr;
    const py = cy + Math.sin(0.4) * rr;
    ctx.fillStyle = p.main;
    ctx.beginPath(); ctx.arc(px, py, 7, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(190,220,255,.7)';
    ctx.beginPath(); ctx.arc(cx, cy, rr * 0.52, 0, TAU); ctx.stroke();
    ctx.fillStyle = 'rgba(120,150,180,.2)';
    ctx.beginPath(); ctx.arc(cx, cy, 30, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(210,230,240,.8)';
    ctx.font = '500 14px "JetBrains Mono", monospace';
    ctx.fillText('VEHICLE', px + 15, py - 8);
    ctx.fillText('SHELL 09', cx + 34, cy - 22);
  } else if (section.id === 'life') {
    const oxy = 0.72;
    ctx.lineWidth = 18;
    ctx.strokeStyle = 'rgba(80,130,120,.2)';
    ctx.beginPath(); ctx.arc(cx, cy, h * 0.24, 0, TAU); ctx.stroke();
    ctx.strokeStyle = p.main;
    ctx.beginPath(); ctx.arc(cx, cy, h * 0.24, -Math.PI / 2, -Math.PI / 2 + TAU * oxy); ctx.stroke();
    ctx.fillStyle = p.main;
    ctx.font = '700 74px "Chakra Petch", sans-serif';
    ctx.fillText('21.0', cx - 82, cy + 10);
    ctx.font = '500 17px "JetBrains Mono", monospace';
    ctx.fillStyle = 'rgba(210,240,230,.7)';
    ctx.fillText('% O₂ / N₂ 79', cx - 64, cy + 40);
    ctx.fillStyle = 'rgba(170,220,205,.75)';
    ctx.fillText('CABIN 101.3 KPA', cx - 80, cy + 66);
  } else {
    // bar-graph instrument
    ctx.fillStyle = 'rgba(210,235,240,.9)';
    ctx.font = '600 90px "Chakra Petch", sans-serif';
    ctx.fillText(s.primary, 70, h * 0.5);
    ctx.fillStyle = 'rgba(180,215,225,.65)';
    ctx.font = '500 16px "JetBrains Mono", monospace';
    ctx.fillText(s.unit, 74, h * 0.5 + 30);
    ctx.fillStyle = p.main;
    ctx.fillRect(74, h * 0.5 + 52, 230 * (0.5 + throttle * 0.5), 6);
    for (let i = 0; i < s.rows.length; i++) {
      const row = s.rows[i];
      const y = 122 + i * 70;
      ctx.fillStyle = 'rgba(200,230,236,.55)';
      ctx.font = '500 15px "JetBrains Mono", monospace';
      ctx.fillText(row.label, w * 0.63, y);
      ctx.fillStyle = 'rgba(230,246,248,.9)';
      ctx.font = '600 18px "JetBrains Mono", monospace';
      ctx.fillText(row.value, w * 0.63 + 120, y);
      ctx.fillStyle = 'rgba(130,170,180,.25)';
      ctx.fillRect(w * 0.63, y + 12, 260, 8);
      ctx.fillStyle = p.main;
      ctx.fillRect(w * 0.63, y + 12, 260 * row.bar, 8);
      ctx.fillRect(w * 0.63 + 260 * row.bar - 2, y + 8, 3, 16);
    }
    if (section.id === 'power' || section.id === 'comms') {
      ctx.strokeStyle = p.main;
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i < 70; i++) {
        const xx = w * 0.37 + i * 3;
        const yy = h * 0.3 + Math.sin(i * 0.35 + throttle * 5) * 18 + Math.sin(i * 1.2) * 7;
        if (i === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy);
      }
      ctx.stroke();
      ctx.globalAlpha = 0.25;
      ctx.fillStyle = p.main;
      ctx.fillRect(w * 0.37, h * 0.3 - 46, 210, 92);
      ctx.globalAlpha = 1;
    }
  }

  ctx.strokeStyle = 'rgba(190,225,235,.14)';
  ctx.strokeRect(18, 82, w - 36, h - 151);
  ctx.fillStyle = p.main;
  ctx.font = '500 14px "JetBrains Mono", monospace';
  ctx.fillText(s.readout, 36, h - 32);
  ctx.fillStyle = 'rgba(200,225,232,.5)';
  ctx.font = '500 13px "JetBrains Mono", monospace';
  ctx.textAlign = 'right';
  ctx.fillText(`HX-9 · ${section.code} · 1280×720 · REV 04`, w - 36, h - 32);
  ctx.textAlign = 'left';

  // scanlines and glass haze
  ctx.fillStyle = 'rgba(0,0,0,.055)';
  for (let y = 0; y < h; y += 4) ctx.fillRect(0, y, w, 1);
  const haze = ctx.createLinearGradient(0, 0, w, h);
  haze.addColorStop(0, 'rgba(255,255,255,.055)');
  haze.addColorStop(0.28, 'rgba(255,255,255,0)');
  haze.addColorStop(0.7, 'rgba(255,255,255,.012)');
  haze.addColorStop(1, 'rgba(255,255,255,.04)');
  ctx.fillStyle = haze;
  ctx.fillRect(0, 0, w, h);
}

export function auxScreen(kind: 'system' | 'engine', color: string): THREE.CanvasTexture {
  const [c, x] = makeCanvas(512, 384);
  x.fillStyle = '#041015';
  x.fillRect(0, 0, 512, 384);
  x.strokeStyle = 'rgba(120,170,180,.12)';
  grid(x, 512, 384, 'rgba(120,170,180,.12)');
  x.strokeStyle = 'rgba(200,230,236,.4)';
  x.lineWidth = 2;
  x.strokeRect(14, 14, 484, 356);
  x.fillStyle = color;
  x.font = '600 20px "JetBrains Mono", monospace';
  x.fillText(kind === 'system' ? 'SYSTEM SYNOPSIS' : 'PROPULSION', 32, 52);
  x.fillStyle = 'rgba(180,215,225,.6)';
  x.font = '500 13px "JetBrains Mono", monospace';
  x.fillText('HX-9 / SYS 04', 32, 74);
  const cx = 256;
  const cy = 208;
  x.strokeStyle = color;
  x.lineWidth = 2;
  x.beginPath(); x.arc(cx, cy, 58, 0, TAU); x.stroke();
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * TAU - Math.PI / 2;
    x.beginPath();
    x.moveTo(cx + Math.cos(a) * 70, cy + Math.sin(a) * 70);
    x.lineTo(cx + Math.cos(a) * 98, cy + Math.sin(a) * 98);
    x.stroke();
    x.fillStyle = i === 0 ? color : 'rgba(170,205,215,.5)';
    x.beginPath();
    x.arc(cx + Math.cos(a) * 108, cy + Math.sin(a) * 108, 3, 0, TAU);
    x.fill();
  }
  x.fillStyle = color;
  x.font = '600 30px "Chakra Petch", sans-serif';
  x.fillText(kind === 'system' ? 'NOM' : 'A/B', cx - 34, cy + 10);
  x.fillStyle = 'rgba(170,205,215,.55)';
  x.font = '500 12px "JetBrains Mono", monospace';
  x.fillText('ALL CHANNELS · 1.00', 32, 340);
  x.textAlign = 'right';
  x.fillText('REV 04', 480, 340);
  x.textAlign = 'left';
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}
