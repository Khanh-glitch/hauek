import * as THREE from 'three';
import type { CockpitSection } from '../data/blueprint';
import { paintScreen, auxScreen, labelTexture, placardTexture } from './textures';
import {
  buildKnob,
  buildToggle,
  fastenerInstances,
  makeLabelPlane,
  loftSurface,
  panelGeometry,
  roundedBox,
  shapeExtrude,
  sweepProfile,
  tube,
} from './geometry';
import type { MaterialLibrary } from './materials';

const C = {
  eyeY: 0.115,
  deckY: -0.94,
  aftZ: 1.28,
  dashZ: -1.3,
  railZ: -1.66,
  halfW: 1.02,
};

export interface CockpitModel {
  group: THREE.Group;
  updateScreen: (section: CockpitSection, throttle: number) => void;
  setThrottle: (value: number) => void;
  ledMaterials: THREE.MeshStandardMaterial[];
  screenMeshes: THREE.Mesh[];
  decals: THREE.Object3D[];
  markers: THREE.Object3D[];
  dispose: () => void;
}

export function buildCockpit(mats: MaterialLibrary): CockpitModel {
  const group = new THREE.Group();
  group.name = 'HX-9 cockpit';
  const disposables: { dispose: () => void }[] = [];
  const track = <T extends { dispose: () => void }>(v: T): T => {
    disposables.push(v);
    return v;
  };
  const screenMeshes: THREE.Mesh[] = [];
  const decals: THREE.Object3D[] = [];
  const markers: THREE.Object3D[] = [];
  const ledMaterials: THREE.MeshStandardMaterial[] = [];

  const add = <T extends THREE.Object3D>(obj: T, parent: THREE.Object3D = group): T => {
    parent.add(obj);
    return obj;
  };

  const box = (
    w: number, h: number, d: number, m: THREE.Material,
    x: number, y: number, z: number,
    rx = 0, ry = 0, rz = 0, r = 0.008,
    parent: THREE.Object3D = group,
  ) => {
    const mesh = new THREE.Mesh(track(roundedBox(w, h, d, r, 2)), m);
    mesh.position.set(x, y, z);
    mesh.rotation.set(rx, ry, rz);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  };

  const mesh = (
    geo: THREE.BufferGeometry, m: THREE.Material,
    x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0,
    parent: THREE.Object3D = group,
  ) => {
    track(geo);
    const obj = new THREE.Mesh(geo, m);
    obj.position.set(x, y, z);
    obj.rotation.set(rx, ry, rz);
    obj.castShadow = true;
    obj.receiveShadow = true;
    parent.add(obj);
    return obj;
  };

  const decal = (texture: THREE.Texture, w: number, h: number, parent: THREE.Object3D = group) => {
    const p = makeLabelPlane(texture, w, h);
    decals.push(p);
    parent.add(p);
    return p;
  };

  const label = (text: string, sub: string, w = 0.12, h = 0.03, color = '#c8d8dd') => {
    const tex = track(labelTexture(text, sub, color, 512, 128));
    return { texture: tex, w, h };
  };

  /* ═══ 1 · PRESSURE SHELL ══════════════════════════════════════════════════
     The lower shell is a lofted, barrel-curved skin rather than slabs. Side
     walls lean inboard toward the canopy rail; the aft bulkhead closes the
     volume. The canopy above the rail is deliberately open to space. */

  const wallMat = track(mats.shell.clone());
  wallMat.side = THREE.DoubleSide;

  // Main deck with a recessed footwell and a raised heel rest.
  box(2.24, 0.075, 2.75, mats.floor, 0, C.deckY - 0.02, -0.34, 0, 0, 0, 0.015);
  box(1.36, 0.038, 0.92, mats.anodized, 0, C.deckY + 0.03, -1.02, 0, 0, 0, 0.006);
  box(0.76, 0.05, 0.3, mats.hull, 0, C.deckY + 0.06, -1.32, -0.1, 0, 0, 0.012);
  for (let i = 0; i < 9; i++) {
    box(0.72 - Math.abs(i - 4) * 0.045, 0.002, 0.022, mats.titanium, 0, C.deckY + 0.087, -1.4 + i * 0.021, -0.1, 0, 0, 0.001);
  }
  // Deck edge gutters and tie-down rings.
  for (const s of [-1, 1]) {
    box(0.055, 0.045, 2.5, mats.anodized, s * 1.05, C.deckY + 0.02, -0.28, 0, 0, 0, 0.008);
    for (let i = 0; i < 4; i++) {
      const ring = new THREE.Mesh(track(new THREE.TorusGeometry(0.026, 0.0045, 6, 18)), mats.brushed);
      ring.position.set(s * 0.92, C.deckY + 0.028, -1.15 + i * 0.6);
      ring.rotation.x = Math.PI / 2;
      add(ring);
    }
  }

  // Lofted side skins. u runs fore/aft, v runs deck to canopy rail.
  for (const s of [-1, 1]) {
    const geo = loftSurface(
      (u, v, out) => {
        const z = -1.62 + u * 3.02;
        const flare = 0.802 + 0.072 * Math.sin(u * Math.PI) - 0.03 * Math.cos((u - 0.45) * 4.4);
        const y = C.deckY + v * (1.02 - 0.05 * Math.sin(u * Math.PI));
        out.set(
          s * (flare - v * 0.10),
          y,
          z + Math.sin(v * Math.PI) * 0.025 + Math.cos(u * Math.PI * 2) * 0.018,
        );
      },
      34,
      16,
    );
    mesh(geo, wallMat);

    // Ribs: real C-sections raised off the skin at a consistent pitch.
    for (let i = 0; i < 5; i++) {
      const z = -1.35 + i * 0.58;
      const pts: THREE.Vector3[] = [];
      for (let k = 0; k <= 6; k++) {
        const v = k / 6;
        pts.push(new THREE.Vector3(s * (0.795 - v * 0.10), C.deckY + v * 0.84, z + Math.sin(v * Math.PI) * 0.02));
      }
      mesh(sweepProfile(pts, [
        [0, 0], [0.018, 0], [0.02, 0.012], [0.02, 0.058], [0.008, 0.065],
        [0, 0.062], [-0.005, 0.01],
      ], { steps: 24, up: new THREE.Vector3(0, 0, 1), caps: true }), mats.hull);
    }

    // Lower padded panel with horizontal stitch seams.
    const padGeo = loftSurface(
      (u, v, out) => {
        const z = -1.42 + u * 2.42;
        const y = C.deckY + 0.1 + v * 0.5;
        out.set(s * (0.788 - v * 0.05 - 0.018 - u * 0.008), y, z + Math.sin(v * Math.PI) * 0.015);
      },
      24,
      12,
    );
    mesh(padGeo, mats.fabric);
    for (let i = 0; i < 5; i++) {
      const pts: THREE.Vector3[] = [];
      for (let k = 0; k <= 14; k++) {
        const u = k / 14;
        pts.push(new THREE.Vector3(s * (0.762 - u * 0.008), C.deckY + 0.18 + i * 0.09, -1.4 + u * 2.34));
      }
      mesh(sweepProfile(pts, [[0, -0.002], [0.004, -0.001], [0.004, 0.0015], [0, 0.003], [-0.004, 0.001]], { steps: 20, up: new THREE.Vector3(0, 1, 0) }), mats.leather);
    }

    // Equipment bay door with a quarter-turn latch.
    const door = box(0.018, 0.42, 0.66, mats.panel, s * 0.774, -0.56, -0.55, 0, 0, s * -0.06, 0.018);
    door.castShadow = true;
    const latchBase = mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.012, 20), mats.anodized, s * 0.760, -0.56, -0.31, 0, 0, Math.PI / 2);
    void latchBase;
    const latch = mesh(new THREE.BoxGeometry(0.006, 0.017, 0.062), mats.brushed, s * 0.751, -0.56, -0.31, 0, 0, Math.PI / 2);
    void latch;
    const caution = track(placardTexture(['CAUTION', 'PRESSURISED', 'PANEL B4'], '#ffb45c', 256, 128));
    const cp = decal(caution, 0.14, 0.07);
    cp.position.set(s * 0.753, -0.38, -0.62);
    cp.rotation.y = s * Math.PI / 2;

    // Grab handle: swept D-section, deliberately inside the reach envelope.
    const handlePts: THREE.Vector3[] = [
      new THREE.Vector3(s * 0.70, -0.38, -0.24),
      new THREE.Vector3(s * 0.655, -0.42, -0.33),
      new THREE.Vector3(s * 0.64, -0.43, -0.55),
      new THREE.Vector3(s * 0.66, -0.41, -0.78),
      new THREE.Vector3(s * 0.72, -0.37, -0.86),
    ];
    mesh(sweepProfile(handlePts, [
      [-0.012, 0], [0.012, 0], [0.014, 0.012], [0.008, 0.018],
      [-0.008, 0.018], [-0.014, 0.012],
    ], { steps: 30, up: new THREE.Vector3(0, 0, 1), caps: true }), mats.brushed);

    // Oxygen hose port with a machined retaining ring.
    const port = mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.055, 28), mats.anodized, s * 0.79, -0.44, 0.0, 0, 0, Math.PI / 2);
    void port;
    const ring = mesh(new THREE.TorusGeometry(0.046, 0.007, 8, 30), mats.brushed, s * 0.762, -0.44, 0.0, 0, Math.PI / 2, 0);
    void ring;
    const o2 = label('O₂', '12 L/MIN', 0.08, 0.024, '#8ff0c3');
    const o2p = decal(o2.texture, o2.w, o2.h);
    o2p.position.set(s * 0.76, -0.39, 0.03);
    o2p.rotation.y = s * Math.PI / 2;

    // Canopy sill / coaming rail.
    const sillPts: THREE.Vector3[] = [
      new THREE.Vector3(s * 0.80, -0.36, -1.62),
      new THREE.Vector3(s * 0.812, -0.33, -1.15),
      new THREE.Vector3(s * 0.80, -0.32, -0.4),
      new THREE.Vector3(s * 0.76, -0.33, 0.55),
      new THREE.Vector3(s * 0.70, -0.35, 1.15),
    ];
    mesh(sweepProfile(sillPts, [
      [0.02, -0.03], [0.062, -0.03], [0.07, -0.008], [0.062, 0.024],
      [0.038, 0.03], [0.018, 0.024], [-0.005, 0.008], [-0.01, -0.01],
    ], { steps: 44, up: new THREE.Vector3(0, 1, 0), caps: true }), mats.brushed);
    // Inner rubber seal sits proud of the rail.
    mesh(sweepProfile(sillPts.map((p) => new THREE.Vector3(p.x, p.y + 0.045, p.z)), [
      [-0.014, 0], [0.014, 0], [0.019, 0.013], [0.012, 0.023], [-0.012, 0.023], [-0.019, 0.013],
    ], { steps: 44, up: new THREE.Vector3(0, 1, 0), caps: true }), mats.seal);

    // Vertical canopy post: aerodynamic section, bolted at both ends.
    const postPts = [
      new THREE.Vector3(s * 0.80, -0.31, -0.94),
      new THREE.Vector3(s * 0.795, 0.02, -0.99),
      new THREE.Vector3(s * 0.76, 0.34, -1.06),
      new THREE.Vector3(s * 0.68, 0.58, -1.15),
      new THREE.Vector3(s * 0.55, 0.74, -1.27),
    ];
    mesh(sweepProfile(postPts, [
      [-0.013, -0.03], [0.013, -0.03], [0.02, -0.005], [0.018, 0.03],
      [0.006, 0.043], [-0.012, 0.035], [-0.021, 0.005],
    ], { steps: 30, up: new THREE.Vector3(0, 0, 1), caps: true }), mats.hull);
    mesh(sweepProfile(postPts.map((p) => p.clone().add(new THREE.Vector3(0, 0, 0.021))), [
      [-0.006, 0], [0.006, 0], [0.008, 0.01], [0, 0.015], [-0.008, 0.01],
    ], { steps: 30, up: new THREE.Vector3(0, 0, 1) }), mats.seal);

    // Full side glazing: a retained pane between the sill and the canopy rail.
    const glazing = loftSurface(
      (u, v, out) => {
        const z = -1.16 + u * 1.92;
        const x = 0.795 + 0.03 * Math.sin(u * Math.PI) - v * 0.06;
        out.set(s * x, -0.23 + v * 0.52, z + v * 0.06);
      },
      16,
      12,
    );
    mesh(glazing, mats.glass);
    // glazing frame: lower and upper sweeps plus two vertical mullions
    mesh(sweepProfile([
      new THREE.Vector3(s * 0.795, -0.23, -1.16),
      new THREE.Vector3(s * 0.812, -0.22, -0.35),
      new THREE.Vector3(s * 0.79, -0.225, 0.76),
    ], [[-0.014, -0.012], [0.014, -0.012], [0.017, 0.006], [0.006, 0.016], [-0.016, 0.008]], {
      steps: 26, up: new THREE.Vector3(0, 1, 0), caps: true,
    }), mats.anodized);
    mesh(sweepProfile([
      new THREE.Vector3(s * 0.735, 0.29, -1.12),
      new THREE.Vector3(s * 0.75, 0.3, -0.35),
      new THREE.Vector3(s * 0.728, 0.295, 0.72),
    ], [[-0.014, -0.012], [0.014, -0.012], [0.017, 0.006], [0.006, 0.016], [-0.016, 0.008]], {
      steps: 26, up: new THREE.Vector3(0, 1, 0), caps: true,
    }), mats.anodized);
    for (const z of [-0.28, 0.42]) {
      mesh(track(roundedBox(0.028, 0.52, 0.026, 0.005, 2)), mats.hull, s * 0.762, 0.03, z, 0, 0, s * 0.035);
    }

    // Side console structure close to the pilot: upholstered panel and rail.
    const coamGeo = loftSurface(
      (u, v, out) => {
        const z = -0.5 + u * 1.34;
        const y = -0.72 + v * 0.42;
        out.set(s * (0.66 + v * 0.12), y, z);
      }, 12, 8,
    );
    mesh(coamGeo, mats.fabric);
    mesh(sweepProfile([
      new THREE.Vector3(s * 0.78, -0.32, -0.5),
      new THREE.Vector3(s * 0.80, -0.31, 0.1),
      new THREE.Vector3(s * 0.76, -0.33, 0.72),
    ], [
      [0.01, -0.026], [0.045, -0.026], [0.052, -0.004], [0.042, 0.02],
      [0.016, 0.026], [-0.008, 0.014], [-0.016, -0.006],
    ], { steps: 26, up: new THREE.Vector3(0, 1, 0), caps: true }), mats.brushed);
  }

  // Aft bulkhead with a structural hatch and service recess.
  box(2.0, 1.2, 0.1, mats.shell, 0, -0.32, C.aftZ, 0, 0, 0, 0.025);
  box(0.92, 0.9, 0.055, mats.panel, 0, -0.33, C.aftZ - 0.065, 0, 0, 0, 0.035);
  const hatch = mesh(panelGeometry(0.78, 0.76, 0.075, 0.028, 0.008), mats.anodized, 0, -0.33, C.aftZ - 0.1);
  void hatch;
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2;
    const bx = Math.cos(a) * 0.34;
    const by = Math.sin(a) * 0.33;
    const w = new THREE.Mesh(track(new THREE.CylinderGeometry(0.012, 0.012, 0.006, 6)), mats.brushed);
    w.position.set(bx, -0.33 + by, C.aftZ - 0.13);
    w.rotation.x = Math.PI / 2;
    add(w);
  }
  const hatchHandle = mesh(sweepProfile([
    new THREE.Vector3(-0.12, -0.28, C.aftZ - 0.16),
    new THREE.Vector3(0, -0.3, C.aftZ - 0.19),
    new THREE.Vector3(0.12, -0.28, C.aftZ - 0.16),
  ], [[-0.014, 0], [0.014, 0], [0.016, 0.014], [0, 0.022], [-0.016, 0.014]], { steps: 20, up: new THREE.Vector3(0, 0, 1), caps: true }), mats.brushed);
  void hatchHandle;
  const hlabel = label('HATCH 02', 'EQUALISE BEFORE OPEN', 0.2, 0.05, '#ffc16b');
  const hp = decal(hlabel.texture, hlabel.w, hlabel.h);
  hp.position.set(0.4, 0.02, C.aftZ - 0.16);

  // Overhead rails: narrow structure, not a closed roof. Space stays visible.
  for (const s of [-1, 1]) {
    const railPts: THREE.Vector3[] = [
      new THREE.Vector3(s * 0.25, 0.74, -1.26),
      new THREE.Vector3(s * 0.32, 0.78, -0.6),
      new THREE.Vector3(s * 0.32, 0.77, 0.25),
      new THREE.Vector3(s * 0.14, 0.78, 1.24),
    ];
    mesh(sweepProfile(railPts, [
      [-0.02, -0.014], [0.02, -0.014], [0.025, 0], [0.02, 0.022],
      [0.006, 0.03], [-0.02, 0.024], [-0.026, 0.004],
    ], { steps: 30, up: new THREE.Vector3(0, 0, 1), caps: true }), mats.hull);
  }
  // Rear canopy bow; sits behind the pilot's head and returns the roof loads
  // into the two side rails. The sky above the pilot stays open.
  const rearBow: THREE.Vector3[] = [];
  for (let i = 0; i <= 18; i++) {
    const a = Math.PI - (i / 18) * Math.PI;
    rearBow.push(new THREE.Vector3(Math.cos(a) * 0.72, 0.3 + Math.sin(a) * 0.42, 0.86));
  }
  mesh(sweepProfile(rearBow, [
    [-0.008, -0.032], [0.022, -0.032], [0.03, -0.008], [0.028, 0.024],
    [0.014, 0.036], [-0.006, 0.032], [-0.016, 0.004],
  ], { steps: 40, up: new THREE.Vector3(0, 0, 1), caps: true }), mats.hull);
  for (const s of [-1, 1]) {
    mesh(sweepProfile([
      new THREE.Vector3(s * 0.66, 0.32, 0.86),
      new THREE.Vector3(s * 0.735, 0.04, 0.86),
      new THREE.Vector3(s * 0.77, -0.3, 0.86),
    ], [[-0.013, 0], [0.013, 0], [0.017, 0.012], [0.006, 0.023], [-0.013, 0.013]], {
      steps: 16, up: new THREE.Vector3(0, 1, 0), caps: true,
    }), mats.hull);
  }
  for (const s of [-1, 1]) {
    mesh(sweepProfile([
      new THREE.Vector3(s * 0.23, 0.77, 1.1),
      new THREE.Vector3(s * 0.2, 0.62, 1.2),
      new THREE.Vector3(s * 0.18, 0.38, 1.26),
    ], [[-0.011, 0], [0.011, 0], [0.014, 0.01], [0.005, 0.019], [-0.011, 0.011]], {
      steps: 14, up: new THREE.Vector3(0, 0, 1), caps: true,
    }), mats.anodized);
  }

  // Overhead switch panel: small, canted, and retained on a machined bracket.
  const ovh = new THREE.Group();
  ovh.position.set(0, 0.6, -0.62);
  ovh.rotation.x = 0.7;
  add(ovh);
  box(0.62, 0.05, 0.38, mats.anodized, 0, -0.012, 0, 0, 0, 0, 0.01, ovh);
  box(0.66, 0.026, 0.42, mats.hull, 0, -0.036, 0, 0, 0, 0, 0.01, ovh);
  box(0.54, 0.03, 0.3, mats.panel, 0, 0.003, 0, 0, 0, 0, 0.005, ovh);
  for (let r = 0; r < 4; r++) {
    for (let k = 0; k < 7; k++) {
      const tog = buildToggle(mats.brushed, k % 3 === 0 ? mats.caution : mats.white, mats.anodized);
      tog.scale.setScalar(0.82);
      tog.position.set(-0.20 + k * 0.066, 0.018, -0.11 + r * 0.07);
      ovh.add(tog);
    }
  }
  for (let i = 0; i < 5; i++) {
    const led = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.006, 0.012), i === 1 ? mats.red : mats.green);
    led.position.set(-0.14 + i * 0.07, 0.034, 0.14);
    ovh.add(led);
  }
  const ovhLabel = label('OVERHEAD', 'BUS CONTROL · GUARDED', 0.18, 0.04, '#8ff0c3');
  const ovl = decal(ovhLabel.texture, ovhLabel.w, ovhLabel.h, ovh);
  ovl.position.set(0, 0.022, 0.118);
  ovl.rotation.x = -Math.PI / 2;

  /* ═══ 2 · CANOPY ARCH & FRAMES ═══════════════════════════════════════════ */

  // Header beam across the top of the windshield only. It stops well above the
  // design eye line so the upper canopy stays open to space.
  const headerPts: THREE.Vector3[] = [];
  for (let i = 0; i <= 24; i++) {
    const u = i / 24;
    const x = -0.86 + u * 1.72;
    headerPts.push(new THREE.Vector3(x, 0.74 + (1 - Math.pow(x / 0.9, 2)) * 0.05, C.railZ - 0.06 + Math.pow(x / 0.9, 2) * 0.04));
  }
  const headerProfile: [number, number][] = [
    [0, -0.022], [0.026, -0.022], [0.032, -0.004], [0.032, 0.024],
    [0.021, 0.034], [0.005, 0.03], [0.002, 0.0], [-0.012, 0.0],
    [-0.014, -0.016], [-0.007, -0.022],
  ];
  mesh(sweepProfile(headerPts, headerProfile, { steps: 46, up: new THREE.Vector3(0, 1, 0), caps: true }), mats.hull);
  mesh(sweepProfile(headerPts.map((p) => p.clone().add(new THREE.Vector3(0, -0.036, 0))), [
    [-0.014, 0], [0.014, 0], [0.018, 0.008], [0.011, 0.019], [-0.011, 0.019], [-0.018, 0.008],
  ], { steps: 46, up: new THREE.Vector3(0, 1, 0), caps: true }), mats.seal);
  // Header fasteners at a measured pitch, oriented to the beam face.
  const headerBolts = [];
  for (let i = 0; i < 19; i++) {
    const x = -0.78 + (i / 18) * 1.56;
    headerBolts.push({
      position: new THREE.Vector3(x, 0.74 + (1 - Math.pow(x / 0.9, 2)) * 0.05, C.railZ - 0.008),
      normal: new THREE.Vector3(0, 0.2, 1).normalize(),
    });
  }
  add(fastenerInstances(headerBolts, mats.brushed, 0.0048, 0.0035));

  // A-pillars sweeping from dash shoulder to arch, with a slimmer inner trim.
  for (const s of [-1, 1]) {
    const pts = [
      new THREE.Vector3(s * 0.79, -0.17, -1.05),
      new THREE.Vector3(s * 0.82, 0.05, -1.22),
      new THREE.Vector3(s * 0.84, 0.28, -1.37),
      new THREE.Vector3(s * 0.86, 0.48, -1.47),
      new THREE.Vector3(s * 0.87, 0.62, -1.52),
      new THREE.Vector3(s * 0.86, 0.72, -1.56),
    ];
    mesh(sweepProfile(pts, [
      [-0.02, -0.028], [0.02, -0.028], [0.032, -0.002], [0.028, 0.045],
      [0.01, 0.058], [-0.02, 0.05], [-0.036, 0.012],
    ], { steps: 36, up: new THREE.Vector3(0, 0, 1), caps: true }), mats.hull);
    mesh(sweepProfile(pts.map((p) => p.clone().add(new THREE.Vector3(s * -0.028, 0, 0))), [
      [-0.012, 0], [0.012, 0], [0.016, 0.008], [0.01, 0.019], [-0.01, 0.019], [-0.016, 0.008],
    ], { steps: 36, up: new THREE.Vector3(0, 0, 1), caps: true }), mats.seal);

    // Canopy latch body and release paddle.
    const latch = new THREE.Group();
    latch.position.set(s * 0.81, 0.02, -1.36);
    gate(latch);
    const body = new THREE.Mesh(track(roundedBox(0.09, 0.075, 0.13, 0.014, 3)), mats.anodized);
    body.castShadow = true;
    latch.add(body);
    const paddle = new THREE.Mesh(track(roundedBox(0.06, 0.018, 0.055, 0.008, 2)), mats.caution);
    paddle.position.set(s * 0.012, 0.034, 0.012);
    paddle.rotation.z = s * 0.18;
    latch.add(paddle);
    const hook = new THREE.Mesh(track(new THREE.CylinderGeometry(0.012, 0.012, 0.055, 8)), mats.brushed);
    hook.rotation.x = Math.PI / 2;
    hook.position.set(0, -0.02, 0.075);
    latch.add(hook);
    const ll = label('CANOPY', 'PULL TO RELEASE', 0.13, 0.032, '#ffc16b');
    const lp = decal(ll.texture, ll.w, ll.h, latch);
    lp.position.set(s * 0.02, 0.012, 0.076);
    lp.rotation.y = s * 0.08;
    add(latch);

    // Structural shoulder gusset.
    mesh(sweepProfile([
      new THREE.Vector3(s * 0.78, -0.08, -1.25),
      new THREE.Vector3(s * 0.75, 0.08, -1.24),
      new THREE.Vector3(s * 0.7, 0.2, -1.1),
    ], [[-0.012, 0], [0.012, 0], [0.016, 0.018], [0, 0.027], [-0.018, 0.018]], { steps: 16, up: new THREE.Vector3(0, 1, 0), caps: true }), mats.titanium);
  }

  // Forward windshield: gently lofted, low-iron glass with a fine edge.
  const glassGeo = loftSurface(
    (u, v, out) => {
      const x = -0.82 + u * 1.64;
      const bow = 1 - Math.pow(x / 0.9, 2);
      out.set(x, 0.02 + v * 0.5 + bow * 0.025, -1.28 - v * 0.2 - bow * 0.055 + Math.pow(v, 2) * 0.04);
    },
    24,
    12,
  );
  mesh(glassGeo, mats.glass);
  // Anti-glare combiner just above the dash, set back from the sight line.
  const combiner = new THREE.Mesh(track(new THREE.PlaneGeometry(0.36, 0.16)), mats.screenGlass);
  combiner.position.set(0, 0.02, -1.15);
  combiner.rotation.x = -0.28;
  add(combiner);
  const hudLines = new THREE.Mesh(
    track(new THREE.PlaneGeometry(0.3, 0.11)),
    track(new THREE.MeshBasicMaterial({
      transparent: true, opacity: 0.35, color: 0x8ff0c3, depthWrite: false,
      map: track(labelTexture('040', 'HDG 042  ▸  VIAS', '#8ff0c3', 512, 256)),
      toneMapped: false,
    })),
  );
  hudLines.position.set(0, 0.022, -1.145);
  hudLines.rotation.x = -0.28;
  add(hudLines);
  screenMeshes.push(hudLines);

  /* ═══ 3 · DASH ════════════════════════════════════════════════════════════ */

  const dash = new THREE.Group();
  dash.position.set(0, -0.275, -1.235);
  dash.rotation.x = -0.16;
  add(dash);

  // Monocoque dash body: compound top contour, rolled ends, joggled lower lip.
  const dashShape = new THREE.Shape();
  dashShape.moveTo(-0.84, -0.24);
  dashShape.lineTo(-0.84, 0.015);
  dashShape.quadraticCurveTo(-0.92, 0.062, -0.8, 0.07);
  dashShape.lineTo(-0.58, 0.085);
  dashShape.quadraticCurveTo(-0.43, 0.095, -0.37, 0.135);
  dashShape.lineTo(-0.2, 0.15);
  dashShape.quadraticCurveTo(0, 0.162, 0.2, 0.15);
  dashShape.lineTo(0.37, 0.135);
  dashShape.quadraticCurveTo(0.43, 0.095, 0.58, 0.085);
  dashShape.lineTo(0.8, 0.07);
  dashShape.quadraticCurveTo(0.92, 0.062, 0.84, 0.015);
  dashShape.lineTo(0.84, -0.24);
  dashShape.quadraticCurveTo(0.88, -0.27, 0.78, -0.27);
  dashShape.lineTo(-0.78, -0.27);
  dashShape.quadraticCurveTo(-0.88, -0.27, -0.84, -0.24);
  const dashGeo = track(shapeExtrude(dashShape, 0.25, 0.018));
  const dashMesh = new THREE.Mesh(dashGeo, mats.hull);
  dashMesh.position.z = -0.16;
  dashMesh.castShadow = true;
  dashMesh.receiveShadow = true;
  dash.add(dashMesh);

  // Machined fascia panels, inset from the dash edge, in three separate parts.
  box(0.74, 0.39, 0.028, mats.anodized, 0, -0.085, 0.098, 0, 0, 0, 0.016, dash);
  box(0.23, 0.21, 0.026, mats.panel, -0.66, -0.08, 0.085, 0, 0.22, 0, 0.012, dash);
  box(0.23, 0.21, 0.026, mats.panel, 0.66, -0.08, 0.085, 0, -0.22, 0, 0.012, dash);

  // Primary display stack.
  const bezelOuter = box(0.78, 0.44, 0.028, mats.bezel, 0, -0.065, 0.112, 0, 0, 0, 0.02, dash);
  void bezelOuter;
  const bezelInner = box(0.74, 0.4, 0.012, mats.anodized, 0, -0.065, 0.13, 0, 0, 0, 0.012, dash);
  void bezelInner;
  const mainCanvas = Object.assign(document.createElement('canvas'), { width: 1024, height: 512 });
  const mainTex = track(new THREE.CanvasTexture(mainCanvas));
  mainTex.colorSpace = THREE.SRGBColorSpace;
  mainTex.anisotropy = 8;
  const screenMat = track(new THREE.MeshBasicMaterial({ map: mainTex, toneMapped: false }));
  const mainScreen = new THREE.Mesh(track(new THREE.PlaneGeometry(0.66, 0.33)), screenMat);
  mainScreen.position.set(0, -0.065, 0.143);
  mainScreen.userData.screen = 'main';
  dash.add(mainScreen);
  screenMeshes.push(mainScreen);
  const gasket = new THREE.Mesh(track(new THREE.TorusGeometry(0.02, 0.006, 6, 4)), mats.seal);
  void gasket;
  box(0.68, 0.35, 0.008, mats.seal, 0, -0.065, 0.138, 0, 0, 0, 0.012, dash);
  const glassPane = new THREE.Mesh(track(new THREE.PlaneGeometry(0.662, 0.332)), mats.screenGlass);
  glassPane.position.set(0, -0.065, 0.147);
  dash.add(glassPane);
  // glare hood, swept to match the dash crown
  const hoodPts: THREE.Vector3[] = [];
  for (let i = 0; i <= 16; i++) {
    const x = -0.39 + (i / 16) * 0.78;
    hoodPts.push(new THREE.Vector3(x, 0.16 + (1 - Math.pow(x / 0.45, 2)) * 0.02, 0.15));
  }
  const hood = mesh(sweepProfile(hoodPts, [
    [0, 0], [0.035, 0.002], [0.045, 0.016], [0.036, 0.032], [0.004, 0.038], [-0.018, 0.026], [-0.028, 0.01],
  ], { steps: 28, up: new THREE.Vector3(0, 1, 0), caps: true }), mats.leather, 0, 0, 0, 0, 0, 0, dash);
  void hood;

  // Auxiliary displays and their bezels.
  for (const [i, s] of [-1, 1].entries()) {
    const tex = auxScreen(i === 0 ? 'system' : 'engine', i === 0 ? '#ffc16b' : '#7de6ff');
    track(tex);
    const mat = new THREE.MeshBasicMaterial({ map: tex, toneMapped: false });
    track(mat);
    const auxGroup = new THREE.Group();
    auxGroup.position.set(s * 0.565, -0.075, 0.105);
    auxGroup.rotation.y = s * -0.26;
    dash.add(auxGroup);
    const frame = new THREE.Mesh(track(roundedBox(0.29, 0.235, 0.026, 0.014, 3)), mats.bezel);
    frame.castShadow = true;
    auxGroup.add(frame);
    const inset = new THREE.Mesh(track(roundedBox(0.26, 0.21, 0.008, 0.008, 2)), mats.anodized);
    inset.position.z = 0.014;
    auxGroup.add(inset);
    const plane = new THREE.Mesh(track(new THREE.PlaneGeometry(0.245, 0.184)), mat);
    plane.position.z = 0.022;
    plane.userData.screen = i === 0 ? 'auxA' : 'auxB';
    auxGroup.add(plane);
    screenMeshes.push(plane);
    const gl = new THREE.Mesh(track(new THREE.PlaneGeometry(0.246, 0.185)), mats.screenGlass);
    gl.position.z = 0.024;
    auxGroup.add(gl);
    // bezel function keys
    for (let k = 0; k < 4; k++) {
      const key = new THREE.Mesh(track(roundedBox(0.035, 0.013, 0.008, 0.002, 2)), mats.brushed);
      key.position.set(-0.09 + k * 0.06, 0.108, 0.02);
      auxGroup.add(key);
    }
  }
  // Dash crown: defroster louvres and a leather-wrapped top line.
  for (let k = 0; k < 11; k++) {
    box(0.028, 0.008, 0.05, mats.dark, -0.4 + k * 0.08, 0.168, 0.02, -0.16, 0, 0, 0.003, dash);
  }
  const crownStitch = new THREE.Group();
  dash.add(crownStitch);
  for (let k = 0; k < 26; k++) {
    const st = new THREE.Mesh(track(new THREE.BoxGeometry(0.012, 0.0025, 0.003)), mats.brushed);
    st.position.set(-0.45 + k * 0.036, 0.19, -0.015);
    st.rotation.x = -0.16;
    crownStitch.add(st);
  }
  // HUD projector: a real housing with glass and a machined collimator mount.
  box(0.2, 0.07, 0.12, mats.anodized, 0.055, 0.17, 0.05, -0.12, 0, 0, 0.012, dash);
  mesh(new THREE.PlaneGeometry(0.14, 0.036), mats.screenGlass, 0.055, 0.195, 0.115, -0.42, 0, 0, dash);

  // Overhead instrument eyebrow with annunciators.
  box(0.86, 0.035, 0.12, mats.leather, 0, 0.13, 0.18, -0.32, 0, 0, 0.012, dash);
  for (let i = 0; i < 7; i++) {
    const m = i === 3 ? mats.caution : i === 5 ? mats.green : mats.warm;
    const led = new THREE.Mesh(track(new THREE.BoxGeometry(0.048, 0.006, 0.014)), m);
    led.position.set(-0.21 + i * 0.07, 0.152, 0.228);
    led.rotation.x = -0.32;
    dash.add(led);
  }

  // Under-dash equipment bay: ribs, connectors and a kick-lamp recess.
  box(1.3, 0.3, 0.09, mats.shell, 0, -0.38, -0.02, 0.05, 0, 0, 0.02, dash);
  for (let i = 0; i < 9; i++) {
    box(0.024, 0.24, 0.016, mats.titanium, -0.54 + i * 0.135, -0.39, 0.032, 0.05, 0, 0, 0.005, dash);
  }
  for (const s of [-1, 1]) {
    const can = mesh(new THREE.CylinderGeometry(0.021, 0.024, 0.05, 16), mats.brushed, s * 0.33, -0.47, 0.04, 0.1, 0, Math.PI / 2, dash);
    void can;
    mesh(new THREE.BoxGeometry(0.14, 0.006, 0.008), s < 0 ? mats.coolLight : mats.warmLight, s * 0.33, -0.53, 0.07, 0, 0, 0, dash);
  }

  // Lower knee bolster, padded at the contact line.
  box(1.5, 0.25, 0.13, mats.leather, 0, -0.44, 0.04, 0.06, 0, 0, 0.05, dash);
  box(0.21, 0.05, 0.03, mats.caution, -0.5, -0.1, 0.172, 0, 0, 0, 0.008, dash);
  box(0.14, 0.026, 0.02, mats.dark, 0.56, -0.11, 0.165, 0, 0, 0, 0.006, dash);
  box(1.34, 0.035, 0.05, mats.anodized, 0, -0.555, 0.1, 0.06, 0, 0, 0.015, dash);
  for (let i = 0; i < 8; i++) {
    const strip = new THREE.Mesh(track(new THREE.BoxGeometry(0.12, 0.011, 0.012)), mats.dark);
    strip.position.set(-0.54 + i * 0.155, -0.405, 0.132);
    strip.rotation.x = 0.06;
    dash.add(strip);
  }

  // Side switch banks on the dash wings.
  for (const s of [-1, 1]) {
    const wing = new THREE.Group();
    wing.position.set(s * 0.595, -0.08, 0.09);
    wing.rotation.set(0, s * -0.22, s * 0.02);
    dash.add(wing);
    box(0.2, 0.19, 0.012, mats.panel, 0, 0, 0, 0, 0, 0, 0.008, wing);
    for (let r = 0; r < 3; r++) {
      for (let k = 0; k < 3; k++) {
        const tog = buildToggle(mats.brushed, r === 0 ? mats.caution : mats.white, mats.anodized);
        tog.scale.setScalar(0.58);
        tog.position.set(-0.058 + k * 0.058, 0.01, -0.055 + r * 0.055);
        wing.add(tog);
      }
    }
    const knob = buildKnob(0.021, 0.018, mats.anodized, mats.white);
    knob.position.set(0.046, 0.008, 0.058);
    knob.scale.setScalar(0.9);
    wing.add(knob);
  }

  // Dash fasteners: two pitches, aligned to the flange, never random.
  const dashBolts = [];
  for (let i = 0; i < 12; i++) {
    const x = -0.9 + i * 0.164;
    dashBolts.push({
      position: new THREE.Vector3(x * 0.86, 0.175, 0.115),
      normal: new THREE.Vector3(0, 0.2, 1).normalize(),
    });
  }
  for (const s of [-1, 1]) {
    for (let i = 0; i < 4; i++) {
      dashBolts.push({
        position: new THREE.Vector3(s * 0.66, -0.2 + i * 0.09, 0.12),
        normal: new THREE.Vector3(0, 0, 1),
      });
    }
  }
  const dbolts = fastenerInstances(dashBolts, mats.brushed, 0.0055, 0.004);
  dash.add(dbolts);

  // Machined placards on the dash lip.
  const p1 = label('HX-9', 'COMMAND DECK · REV 04', 0.17, 0.045, '#9fb4bb');
  const p1m = decal(p1.texture, p1.w, p1.h, dash);
  p1m.position.set(-0.44, 0.085, 0.186);
  const p2 = label('MASTER CAUTION', 'PUSH TO RESET', 0.16, 0.04, '#ffc16b');
  const p2m = decal(p2.texture, p2.w, p2.h, dash);
  p2m.position.set(0.4, 0.085, 0.186);
  // A guarded switch cluster below the main screen.
  for (let k = 0; k < 5; k++) {
    const tog = buildToggle(mats.brushed, k === 4 ? mats.red : mats.white, k === 4 ? mats.anodized : null);
    tog.scale.setScalar(0.7);
    tog.position.set(-0.145 + k * 0.072, -0.34, 0.155);
    dash.add(tog);
  }
  const guard = box(0.09, 0.05, 0.024, mats.caution, 0.145, -0.335, 0.16, 0.35, 0, 0, 0.008, dash);
  void guard;

  /* ═══ 4 · GLARESHIELD & DASH COWL ══════════════════════════════════════ */
  const cowlPts: THREE.Vector3[] = [];
  for (let i = 0; i <= 32; i++) {
    const x = -0.88 + (i / 32) * 1.76;
    cowlPts.push(new THREE.Vector3(x, -0.15 + (1 - Math.pow(x / 0.94, 2)) * 0.02, -1.09 - Math.pow(x / 0.98, 2) * 0.05));
  }
  mesh(sweepProfile(cowlPts, [
    [0, 0], [0.17, 0.008], [0.205, 0.026], [0.215, 0.05], [0.2, 0.06],
    [0.17, 0.055], [0.11, 0.032], [0, 0.018],
  ], { steps: 46, up: new THREE.Vector3(0, 1, 0), caps: true }), mats.leather);
  // rolled lip in aluminium
  mesh(sweepProfile(cowlPts.map((p) => p.clone().setZ(p.z + 0.202).setY(p.y + 0.057)), [
    [-0.012, 0], [0.012, 0], [0.016, 0.012], [0, 0.021], [-0.016, 0.012],
  ], { steps: 46, up: new THREE.Vector3(0, 1, 0), caps: true }), mats.anodized);
  // Amber task light strip under the brow. Emissive mesh only; not a light.
  const strip = new THREE.Mesh(track(new THREE.BoxGeometry(0.6, 0.006, 0.012)), mats.warmLight);
  strip.position.set(0, -0.142, -1.1);
  add(strip);
  screenMeshes.push(strip);

  // Concealed cabin task strip under the dash lip: an emissive surface, not a light.
  for (const s of [-1, 1]) {
    mesh(new THREE.BoxGeometry(0.42, 0.005, 0.012), mats.warmLight, s * 0.72, -0.57, -1.06, 0, 0, 0);
  }
  mesh(new THREE.BoxGeometry(0.5, 0.004, 0.01), mats.coolLight, 0, -0.885, -0.7);

  /* ═══ 5 · CENTRE PEDESTAL ═══════════════════════════════════════════════ */
  const ped = new THREE.Group();
  ped.position.set(0, -0.6, -0.42);
  ped.rotation.x = -0.08;
  add(ped);
  box(0.45, 0.22, 0.68, mats.carbon, 0, 0, 0, 0, 0, 0, 0.025, ped);
  box(0.48, 0.032, 0.7, mats.anodized, 0, 0.12, 0, 0, 0, 0, 0.014, ped);
  box(0.42, 0.018, 0.64, mats.panel, 0, 0.14, 0, 0, 0, 0, 0.01, ped);
  // Forearm pad
  box(0.44, 0.05, 0.22, mats.leather, 0, 0.15, -0.21, 0, 0, 0, 0.02, ped);
  // Throttle quadrant base with two slots and quadrant markings.
  box(0.26, 0.035, 0.23, mats.anodized, -0.06, 0.165, 0.1, 0, 0, 0, 0.01, ped);
  const levers: THREE.Group[] = [];
  for (let i = 0; i < 2; i++) {
    const pivot = new THREE.Group();
    pivot.position.set(-0.11 + i * 0.075, 0.2, 0.12);
    ped.add(pivot);
    const arm = new THREE.Mesh(track(roundedBox(0.019, 0.115, 0.045, 0.006, 3)), mats.brushed);
    arm.position.y = 0.052;
    arm.castShadow = true;
    pivot.add(arm);
    const grip = new THREE.Mesh(track(new THREE.CapsuleGeometry(0.0205, 0.042, 5, 12)), mats.rubber);
    grip.position.y = 0.108;
    grip.rotation.x = -0.2;
    pivot.add(grip);
    const collar = new THREE.Mesh(track(new THREE.TorusGeometry(0.026, 0.004, 6, 18)), i === 0 ? mats.warm : mats.cyan);
    collar.position.y = 0.083;
    collar.rotation.x = Math.PI / 2;
    pivot.add(collar);
    const btn = new THREE.Mesh(track(new THREE.CylinderGeometry(0.006, 0.006, 0.004, 12)), mats.caution);
    btn.position.set(0, 0.135, -0.016);
    pivot.add(btn);
    pivot.rotation.x = -0.3;
    levers.push(pivot);
  }
  // Slot gates and friction labels.
  for (let i = 0; i < 7; i++) {
    box(0.15, 0.004, 0.008, mats.titanium, -0.06, 0.183, 0.0 + i * 0.027, 0, 0, 0, 0.002, ped);
  }
  const lq = label('THROTTLE', 'FRICTION · DETENT 04', 0.2, 0.045, '#ffc16b');
  const lqm = decal(lq.texture, lq.w, lq.h, ped);
  lqm.position.set(-0.06, 0.18, -0.045);
  // Trim wheel, cursor controller, guarded switches.
  const trim = buildKnob(0.032, 0.02, mats.anodized, mats.white);
  trim.rotation.set(Math.PI / 2, 0, 0);
  trim.position.set(0.17, 0.195, 0.3);
  ped.add(trim);
  const ball = new THREE.Mesh(track(new THREE.SphereGeometry(0.022, 20, 14)), mats.rubber);
  ball.position.set(0.12, 0.2, 0.13);
  ball.scale.y = 0.8;
  ped.add(ball);
  const collar = new THREE.Mesh(track(new THREE.CylinderGeometry(0.033, 0.038, 0.014, 24)), mats.brushed);
  collar.position.set(0.12, 0.18, 0.13);
  ped.add(collar);
  for (let i = 0; i < 3; i++) {
    const tog = buildToggle(mats.brushed, i === 2 ? mats.caution : mats.white, i === 2 ? mats.anodized : null);
    tog.scale.setScalar(0.85);
    tog.position.set(0.15, 0.2, -0.07 + i * 0.045);
    tog.rotation.x = -Math.PI / 2;
    tog.rotation.z = 0.1;
    ped.add(tog);
  }
  // Annunciator row, readable from the eye point.
  for (let i = 0; i < 5; i++) {
    const led = new THREE.Mesh(track(new THREE.BoxGeometry(0.035, 0.005, 0.012)), i === 2 ? mats.caution : mats.green);
    led.position.set(-0.16 + i * 0.048, 0.158, 0.31);
    ped.add(led);
  }
  // Pedestal grab rails, C-section with caps.
  for (const s of [-1, 1]) {
    mesh(sweepProfile([
      new THREE.Vector3(s * 0.25, 0.1, 0.28),
      new THREE.Vector3(s * 0.28, 0.12, 0.02),
      new THREE.Vector3(s * 0.29, 0.14, -0.25),
      new THREE.Vector3(s * 0.26, 0.17, -0.39),
    ], [[-0.012, 0], [0.012, 0], [0.015, 0.012], [0, 0.02], [-0.015, 0.012]], {
      steps: 22, up: new THREE.Vector3(0, 0, 1), caps: true,
    }), mats.titanium);

    const gripPad = box(0.05, 0.018, 0.1, mats.seal, s * 0.585, -0.42, -0.36, s * -0.08, 0, 0, 0.008);
    void gripPad;
  }

  // Rudder / brake pedals with machined rubbing surfaces.
  for (const s of [-1, 1]) {
    const pgroup = new THREE.Group();
    pgroup.position.set(s * 0.26, -0.79, -1.06);
    pgroup.rotation.x = -0.34;
    add(pgroup);
    const plate = new THREE.Mesh(track(roundedBox(0.18, 0.22, 0.026, 0.018, 3)), mats.anodized);
    plate.castShadow = true;
    pgroup.add(plate);
    for (let i = 0; i < 6; i++) {
      const slat = new THREE.Mesh(track(new THREE.BoxGeometry(0.145, 0.012, 0.007)), mats.titanium);
      slat.position.set(0, -0.07 + i * 0.028, 0.016);
      pgroup.add(slat);
    }
    const hinge = new THREE.Mesh(track(new THREE.CylinderGeometry(0.024, 0.024, 0.2, 18)), mats.brushed);
    hinge.rotation.z = Math.PI / 2;
    hinge.position.set(0, -0.12, -0.02);
    pgroup.add(hinge);
    for (const sx of [-1, 1]) {
      const arm = new THREE.Mesh(track(new THREE.BoxGeometry(0.026, 0.2, 0.035)), mats.hull);
      arm.position.set(sx * 0.11, -0.12, -0.08);
      arm.rotation.x = 0.25;
      pgroup.add(arm);
    }
  }
  // Floor tread plates and utility covers, visible past the dash edge.
  for (let i = 0; i < 5; i++) {
    box(0.52 - i * 0.02, 0.004, 0.11, mats.titanium, 0, C.deckY + 0.045, -0.9 + i * 0.22, 0, 0, 0, 0.004);
  }
  box(0.24, 0.01, 0.18, mats.caution, -0.52, C.deckY + 0.05, -0.72, 0, 0.1, 0, 0.008);
  const deckLabel = label('DECK 01', 'NO STEP · HEEL LINE', 0.14, 0.035, '#ffc16b');
  const dl = decal(deckLabel.texture, deckLabel.w, deckLabel.h);
  dl.position.set(0.36, C.deckY + 0.06, -0.86);
  dl.rotation.set(-Math.PI / 2, 0, 0.12);

  // Floor heel wells and pedal guide rails.
  for (const s of [-1, 1]) {
    box(0.035, 0.052, 0.72, mats.anodized, s * 0.12, -0.885, -1.02, 0, 0, 0, 0.008);
    box(0.035, 0.052, 0.72, mats.anodized, s * 0.4, -0.885, -1.02, 0, 0, 0, 0.008);
  }

  /* ═══ 6 · SEAT ═══════════════════════════════════════════════════════════ */
  const seat = new THREE.Group();
  seat.position.set(0, 0, 0.78);
  add(seat);

  // Rails and rollers first, so the shell visibly sits on its adjustment track.
  for (const s of [-1, 1]) {
    box(0.07, 0.055, 0.92, mats.anodized, s * 0.29, -0.855, 0.03, 0, 0, 0, 0.01, seat);
    for (let i = 0; i < 7; i++) {
      box(0.02, 0.012, 0.022, mats.dark, s * 0.29, -0.828, -0.38 + i * 0.13, 0, 0, 0, 0.003, seat);
    }
    const carriage = new THREE.Mesh(track(roundedBox(0.105, 0.09, 0.2, 0.018, 3)), mats.titanium);
    carriage.position.set(s * 0.29, -0.79, 0.16);
    seat.add(carriage);
    const roller = new THREE.Mesh(track(new THREE.CylinderGeometry(0.024, 0.024, 0.12, 16)), mats.brushed);
    roller.rotation.x = Math.PI / 2;
    roller.position.set(s * 0.33, -0.815, -0.12);
    seat.add(roller);
  }

  // Seat side profile: a genuine C-shaped monocoque, extruded across the hips.
  const seatProfile = new THREE.Shape();
  seatProfile.moveTo(-0.42, -0.58);
  seatProfile.quadraticCurveTo(-0.45, -0.5, -0.36, -0.47);
  seatProfile.lineTo(-0.02, -0.5);
  seatProfile.quadraticCurveTo(0.18, -0.52, 0.25, -0.4);
  seatProfile.quadraticCurveTo(0.33, -0.24, 0.36, -0.02);
  seatProfile.quadraticCurveTo(0.41, 0.24, 0.44, 0.5);
  seatProfile.quadraticCurveTo(0.45, 0.6, 0.35, 0.61);
  seatProfile.lineTo(0.08, 0.59);
  seatProfile.quadraticCurveTo(0.01, 0.56, 0.03, 0.45);
  seatProfile.quadraticCurveTo(0.07, 0.24, 0.02, 0.03);
  seatProfile.quadraticCurveTo(-0.02, -0.15, -0.2, -0.19);
  seatProfile.quadraticCurveTo(-0.4, -0.24, -0.47, -0.36);
  seatProfile.quadraticCurveTo(-0.5, -0.47, -0.42, -0.58);
  const seatGeo = track(shapeExtrude(seatProfile, 0.54, 0.018));
  seatGeo.translate(0, 0, -0.27);
  seatGeo.rotateY(-Math.PI / 2);
  const seatShell = new THREE.Mesh(seatGeo, mats.carbon);
  seatShell.castShadow = true;
  seatShell.receiveShadow = true;
  seat.add(seatShell);

  // Cushions: compressed edges, separate wear surfaces.
  const panCushion = box(0.5, 0.11, 0.5, mats.fabric, 0, -0.49, -0.03, 0.06, 0, 0, 0.045, seat);
  panCushion.scale.set(1, 1, 1);
  box(0.42, 0.04, 0.5, mats.leather, 0, -0.555, 0.02, 0.03, 0, 0, 0.02, seat);
  const back = box(0.48, 0.7, 0.11, mats.fabric, 0, 0.06, 0.34, -0.19, 0, 0, 0.055, seat);
  back.scale.set(1, 1, 1);
  box(0.44, 0.15, 0.07, mats.fabric, 0, -0.15, 0.3, -0.1, 0, 0, 0.03, seat);
  for (const s of [-1, 1]) {
    const bolster = box(0.1, 0.4, 0.13, mats.fabric, s * 0.28, -0.43, 0.0, 0.05, 0, s * -0.14, 0.045, seat);
    bolster.rotation.y = s * -0.16;
    box(0.09, 0.58, 0.11, mats.fabric, s * 0.28, 0.08, 0.34, -0.19, s * -0.08, 0, 0.04, seat);
    // Armrest on a machined post.
    box(0.1, 0.055, 0.48, mats.leather, s * 0.39, -0.25, -0.02, 0.02, 0, 0, 0.025, seat);
    const post = new THREE.Mesh(track(new THREE.CylinderGeometry(0.024, 0.03, 0.21, 14)), mats.anodized);
    post.position.set(s * 0.39, -0.37, 0.18);
    seat.add(post);
    const pad = new THREE.Mesh(track(roundedBox(0.1, 0.035, 0.42, 0.016, 3)), mats.leather);
    pad.position.set(s * 0.39, -0.218, -0.02);
    seat.add(pad);
  }
  // Headrest, adjustable on a visible guide rail.
  for (const s of [-1, 1]) {
    const rail = new THREE.Mesh(track(new THREE.BoxGeometry(0.014, 0.21, 0.014)), mats.brushed);
    rail.position.set(s * 0.12, 0.66, 0.45);
    seat.add(rail);
    for (let i = 0; i < 4; i++) {
      const notch = new THREE.Mesh(track(new THREE.BoxGeometry(0.018, 0.006, 0.018)), mats.dark);
      notch.position.set(s * 0.12, 0.58 + i * 0.05, 0.452);
      seat.add(notch);
    }
  }
  const headrest = box(0.34, 0.18, 0.1, mats.fabric, 0, 0.72, 0.46, -0.16, 0, 0, 0.045, seat);
  headrest.rotation.z = 0;
  const harnessPlate = box(0.3, 0.055, 0.025, mats.carbon, 0, 0.77, 0.41, -0.16, 0, 0, 0.01, seat);
  void harnessPlate;
  const seatLabel = label('HX-9', 'SEAT 01 · 9G SHELL', 0.16, 0.04, '#9fb4bb');
  const sl = decal(seatLabel.texture, seatLabel.w, seatLabel.h, seat);
  sl.position.set(0, 0.71, 0.515);
  sl.rotation.x = -0.16;

  // Five-point harness. Shoulder belts have a real service loop and hardware.
  const beltMat = track(new THREE.MeshStandardMaterial({
    color: 0x6d6b60, roughness: 0.84, metalness: 0.03, bumpMap: mats.fabric.bumpMap, bumpScale: 0.12,
  }));
  const beltProfile: [number, number][] = [[-0.022, -0.003], [0.022, -0.003], [0.024, 0.002], [0.022, 0.005], [-0.022, 0.005], [-0.024, 0.002]];
  for (const s of [-1, 1]) {
    const shoulderPts = [
      new THREE.Vector3(s * 0.13, 0.8, 0.46),
      new THREE.Vector3(s * 0.2, 0.65, 0.52),
      new THREE.Vector3(s * 0.24, 0.4, 0.47),
      new THREE.Vector3(s * 0.21, 0.06, 0.31),
      new THREE.Vector3(s * 0.14, -0.16, 0.18),
      new THREE.Vector3(s * 0.06, -0.31, 0.16),
    ];
    const belt = mesh(sweepProfile(shoulderPts, beltProfile, { steps: 34, up: new THREE.Vector3(0, 0, 1), caps: true }), beltMat, 0, 0, 0, 0, 0, 0, seat);
    belt.castShadow = true;
    const lapPts = [
      new THREE.Vector3(s * 0.38, -0.28, 0.08),
      new THREE.Vector3(s * 0.3, -0.38, 0.01),
      new THREE.Vector3(s * 0.16, -0.45, 0.04),
      new THREE.Vector3(s * 0.04, -0.46, 0.1),
    ];
    mesh(sweepProfile(lapPts, beltProfile, { steps: 22, up: new THREE.Vector3(0, 1, 0), caps: true }), beltMat, 0, 0, 0, 0, 0, 0, seat);
    // Anchor bracket.
    box(0.07, 0.026, 0.09, mats.brushed, s * 0.38, -0.28, 0.08, 0, 0, 0, 0.008, seat);
  }
  const buckle = box(0.1, 0.07, 0.045, mats.brushed, 0, -0.45, 0.16, 0, 0, 0, 0.014, seat);
  void buckle;
  box(0.07, 0.024, 0.02, mats.red, 0, -0.46, 0.19, 0, 0, 0, 0.006, seat);

  // Seat-shell fasteners and rail stops. The pitch follows the flange, at 40 mm.
  const seatBolts = [];
  for (const s of [-1, 1]) {
    for (let i = 0; i < 5; i++) {
      seatBolts.push({ position: new THREE.Vector3(s * 0.2, -0.46 + i * 0.045, -0.35 + i * 0.02), normal: new THREE.Vector3(0, -0.4, -1).normalize() });
    }
    for (let i = 0; i < 3; i++) {
      seatBolts.push({ position: new THREE.Vector3(s * 0.27, -0.34 + i * 0.02, 0.29), normal: new THREE.Vector3(s, 0, 0.22).normalize() });
    }
  }
  seat.add(fastenerInstances(seatBolts, mats.brushed, 0.0055, 0.004));
  // Harness anchor plates and a machined adjuster on the lap belt.
  for (const s of [-1, 1]) {
    box(0.055, 0.016, 0.07, mats.titanium, s * 0.2, 0.53, 0.47, -0.18, 0, 0, 0.004, seat);
    box(0.04, 0.032, 0.016, mats.brushed, s * 0.21, 0.05, 0.34, -0.19, 0, 0, 0.004, seat);
    const buckleEdge = new THREE.Mesh(track(new THREE.BoxGeometry(0.02, 0.05, 0.032)), mats.anodized);
    buckleEdge.position.set(s * 0.09, -0.45, 0.18);
    seat.add(buckleEdge);
  }
  const pull = new THREE.Mesh(track(new THREE.CylinderGeometry(0.007, 0.007, 0.055, 8)), mats.caution);
  pull.rotation.z = Math.PI / 2;
  pull.position.set(0, -0.5, 0.22);
  seat.add(pull);

  // Ejection / extraction handle under the pan edge.
  mesh(sweepProfile([
    new THREE.Vector3(-0.11, -0.58, -0.28),
    new THREE.Vector3(0, -0.6, -0.33),
    new THREE.Vector3(0.11, -0.58, -0.28),
  ], [[-0.014, 0], [0.014, 0], [0.017, 0.012], [0, 0.021], [-0.017, 0.012]], { steps: 18, up: new THREE.Vector3(0, 0, 1), caps: true }), mats.caution, 0, 0, 0, 0, 0, 0, seat);

  /* ═══ 7 · SIDE CONSOLES & HOSES ═════════════════════════════════════════ */
  for (const s of [-1, 1]) {
    const con = new THREE.Group();
    con.position.set(s * 0.6, -0.56, -0.42);
    con.rotation.set(0.06, s * -0.34, s * 0.04);
    add(con);
    box(0.23, 0.07, 0.42, mats.anodized, 0, 0, 0, 0, 0, 0, 0.016, con);
    box(0.2, 0.03, 0.38, mats.panel, 0, 0.04, 0, 0, 0, 0, 0.01, con);
    const pad = box(0.17, 0.04, 0.26, mats.leather, 0, 0.065, 0.07, 0, 0, 0, 0.016, con);
    pad.castShadow = true;
    for (let k = 0; k < 3; k++) {
      const tog = buildToggle(mats.brushed, k === 0 ? mats.caution : mats.white, null);
      tog.scale.setScalar(0.55);
      tog.position.set(0, 0.05, -0.17 + k * 0.04);
      con.add(tog);
    }
    const knob = buildKnob(0.022, 0.018, mats.anodized, mats.cyan);
    knob.position.set(0, 0.05, -0.04);
    con.add(knob);
  }

  // Right-hand translational controller: gimbal rings and a bolted base.
  const hc = new THREE.Group();
  hc.position.set(0.38, -0.62, -0.35);
  add(hc);
  mesh(new THREE.CylinderGeometry(0.1, 0.115, 0.035, 28), mats.anodized, 0, 0, 0, 0, 0, 0, hc);
  mesh(new THREE.TorusGeometry(0.076, 0.007, 8, 32), mats.brushed, 0, 0.024, 0, Math.PI / 2, 0, 0, hc);
  mesh(new THREE.TorusGeometry(0.058, 0.0055, 8, 28), mats.titanium, 0, 0.035, 0, Math.PI / 2, 0, 0, hc);
  const grip = mesh(new THREE.CapsuleGeometry(0.026, 0.09, 6, 14), mats.rubber, 0, 0.11, 0, 0.22, 0, 0, hc);
  grip.scale.set(1, 1, 0.86);
  mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.006, 10), mats.red, 0.018, 0.15, 0, 0, 0, 0, hc);
  mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.006, 10), mats.warm, -0.018, 0.14, 0, 0, 0, 0, hc);

  // Under-dash cable bundles with service loops and P-clamps.
  for (let b = 0; b < 3; b++) {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 8; i++) {
      const x = -0.68 + (i / 8) * 1.36;
      pts.push(new THREE.Vector3(x, -0.68 + Math.sin(i * 0.8 + b) * 0.008, -1.12 - b * 0.022 + Math.sin(i * 1.3) * 0.012));
    }
    const cable = tube(pts, 0.0085 - b * 0.0012, b === 1 ? mats.caution : mats.rubber, 8, 64);
    add(cable);
    for (let i = 0; i < 4; i++) {
      const clamp = new THREE.Mesh(track(new THREE.TorusGeometry(0.014, 0.0032, 6, 16, Math.PI * 1.6)), mats.brushed);
      clamp.position.set(-0.4 + i * 0.27, -0.68 + Math.sin((i * 2.4 + b) * 0.8) * 0.006, -1.12 - b * 0.022);
      clamp.rotation.y = 0.3;
      add(clamp);
    }
  }
  // Connectors terminate the harness into a bulkhead fitting.
  box(0.11, 0.07, 0.03, mats.anodized, -0.62, -0.66, -1.15, 0, 0, 0, 0.008);
  for (let i = 0; i < 2; i++) {
    const conn = mesh(new THREE.CylinderGeometry(0.022, 0.028, 0.055, 18), mats.brushed, -0.66 + i * 0.065, -0.66, -1.16, 0, 0, Math.PI / 2);
    conn.rotation.y = 0.0;
    const collar2 = mesh(new THREE.TorusGeometry(0.028, 0.005, 6, 20), mats.titanium, -0.66 + i * 0.065, -0.66, -1.135, 0, Math.PI / 2, 0);
    void collar2;
  }

  // Corrugated oxygen hose, clipped to the left wall with a quick-disconnect.
  const hosePts = [
    new THREE.Vector3(-0.86, -0.18, 0.0),
    new THREE.Vector3(-0.79, -0.29, 0.16),
    new THREE.Vector3(-0.66, -0.36, 0.32),
    new THREE.Vector3(-0.54, -0.32, 0.43),
    new THREE.Vector3(-0.45, -0.22, 0.48),
  ];
  const hose = tube(hosePts, 0.019, mats.seal, 12, 64);
  add(hose);
  const hoseCurve = new THREE.CatmullRomCurve3(hosePts, false, 'centripetal', 0.5);
  for (let i = 0; i < 14; i++) {
    const p = hoseCurve.getPointAt(i / 13);
    const t = hoseCurve.getTangentAt(i / 13);
    const rib = new THREE.Mesh(track(new THREE.TorusGeometry(0.0205, 0.0032, 6, 18)), mats.rubber);
    rib.position.copy(p);
    rib.rotation.x = Math.PI / 2;
    rib.rotation.z = Math.atan2(t.y, t.x);
    add(rib);
  }
  const qd = mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.06, 20), mats.brushed, -0.45, -0.21, 0.49, 0.1, 0.4, 0.7);
  void qd;

  // Wall fastener runs, seam pitch 36 mm, placed on the actual skin line.
  for (const s of [-1, 1]) {
    const pts = [];
    for (let i = 0; i < 14; i++) {
      pts.push({
        position: new THREE.Vector3(s * 0.868, -0.82 + (i % 2) * 0.035, -1.38 + Math.floor(i / 2) * 0.42),
        normal: new THREE.Vector3(s, 0, 0),
      });
    }
    add(fastenerInstances(pts, mats.brushed, 0.0048, 0.0035));
  }
  // Arch fasteners follow the arc, oriented along the local normal.
  const archBolts = [];
  for (let i = 0; i < 18; i++) {
    const a = Math.PI - (i / 17) * Math.PI;
    archBolts.push({
      position: new THREE.Vector3(Math.cos(a) * 0.937, 0.16 + Math.sin(a) * 0.628, C.railZ + Math.sin(a) * 0.03),
      normal: new THREE.Vector3(Math.cos(a), Math.sin(a), 0),
    });
  }
  add(fastenerInstances(archBolts, mats.brushed, 0.0052, 0.004));

  // Final small labels at eye level.
  const warn = track(placardTexture(['NO STEP', 'SEAL SURFACE'], '#ffc16b', 256, 128));
  const wp = decal(warn, 0.14, 0.07);
  wp.position.set(0.74, 0.045, -1.55);
  wp.rotation.set(-0.15, -0.35, 0);
  for (const s of [-1, 1]) {
    const eye = label('EYE', 'REF 1.08 M', 0.075, 0.023, '#9fb4bb');
    const ep = decal(eye.texture, eye.w, eye.h);
    ep.position.set(s * 0.94, 0.18, -1.3);
    ep.rotation.y = s * -0.2;
  }

  /* ═══ 8 · SCREENS ═══════════════════════════════════════════════════════ */
  const paint = (section: CockpitSection, throttle: number) => {
    paintScreen(mainCanvas, section, throttle);
    mainTex.needsUpdate = true;
  };

  const setThrottle = (v: number) => {
    const t = THREE.MathUtils.clamp(v, 0, 1);
    levers.forEach((l, i) => {
      l.rotation.x = -0.45 + t * 0.4 + i * 0.025;
    });
  };

  // Initial content.
  const seedSection = {
    id: 'flight',
    index: '01', code: 'FLT', label: 'Flight', labelVi: 'Bay', title: 'Primary flight',
    kicker: '', description: '', stats: [], color: '#7de6ff',
    screen: {
      heading: 'PRIMARY FLIGHT DISPLAY', sub: 'LANE A / NOMINAL', primary: '7 812', unit: 'M · S⁻¹',
      rows: [
        { label: 'ALT', value: '4 012.6 KM', bar: 0.62 },
        { label: 'VRT SPD', value: '+ 2.4 M/S', bar: 0.41 },
        { label: 'ATT', value: '+1.4 / −0.2', bar: 0.5 },
        { label: 'G-LOAD', value: '1.00 G', bar: 0.28 },
      ],
      readout: 'GUIDANCE · VECTOR 7B · CORRIDOR NOMINAL',
    },
  } as CockpitSection;

  paint(seedSection, 0.62);
  setThrottle(0.62);

  return {
    group,
    updateScreen: paint,
    setThrottle,
    ledMaterials,
    screenMeshes,
    decals,
    markers,
    dispose: () => disposables.forEach((d) => d.dispose()),
  };

  function gate(_o: THREE.Object3D) {
    // Latch is physical hardware; keep it out of the screen/led registries.
  }
}

export const COCKPIT_DECK_Y = C.deckY;
export const COCKPIT_EYE_Y = C.eyeY;
