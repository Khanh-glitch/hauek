import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { buildCockpit, type CockpitModel } from './cockpit';
import { buildMaterials, type MaterialLibrary } from './materials';
import { environmentTexture, makeCanvas, nebulaTexture, planetTexture } from './textures';
import type { CockpitSection, ViewId } from '../data/blueprint';
import { STUDY_VIEWS } from '../data/blueprint';

export interface CockpitEngine {
  setView: (view: ViewId) => void;
  setSection: (section: CockpitSection) => void;
  setThrottle: (v: number) => void;
  setGrayscale: (on: boolean) => void;
  setCalloutActive: (on: boolean) => void;
  refreshScreens: () => void;
  dispose: () => void;
}

function radialSprite(inner: string, outer: string): THREE.CanvasTexture {
  const [c, x] = makeCanvas(256, 256);
  const g = x.createRadialGradient(128, 128, 0, 128, 128, 126);
  g.addColorStop(0, inner);
  g.addColorStop(0.18, inner);
  g.addColorStop(0.42, outer);
  g.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = g;
  x.fillRect(0, 0, 256, 256);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function starField(count: number, radiusMin: number, radiusMax: number, size: number, seed: number) {
  const positions = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);
  let s = seed;
  const rnd = () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
  const color = new THREE.Color();
  for (let i = 0; i < count; i++) {
    const r = radiusMin + rnd() * (radiusMax - radiusMin);
    const theta = rnd() * Math.PI * 2;
    const phi = Math.acos(2 * rnd() - 1);
    positions[i * 3] = Math.sin(phi) * Math.cos(theta) * r;
    positions[i * 3 + 1] = Math.cos(phi) * r;
    positions[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * r;
    const warm = rnd() > 0.86;
    color.setHSL(warm ? 0.1 : 0.55, warm ? 0.28 : 0.2, 0.62 + rnd() * 0.35);
    colors[i * 3] = color.r;
    colors[i * 3 + 1] = color.g;
    colors[i * 3 + 2] = color.b;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  const mat = new THREE.PointsMaterial({
    size,
    sizeAttenuation: true,
    vertexColors: true,
    transparent: true,
    opacity: 0.72,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    toneMapped: false,
  });
  return new THREE.Points(geo, mat);
}

export function createCockpitEngine(canvas: HTMLCanvasElement): CockpitEngine {
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: 'high-performance',
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
  renderer.setSize(canvas.clientWidth, canvas.clientHeight, false);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.14;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x020508);
  const camera = new THREE.PerspectiveCamera(58, 1, 0.05, 240);

  const materials: MaterialLibrary = buildMaterials();
  const envTex = environmentTexture();
  const pmrem = new THREE.PMREMGenerator(renderer);
  const envRT = pmrem.fromEquirectangular(envTex);
  scene.environment = envRT.texture;
  scene.environmentIntensity = 1.05;
  envTex.dispose();
  pmrem.dispose();

  const model: CockpitModel = buildCockpit(materials);
  scene.add(model.group);

  /* ── light rig ───────────────────────────────────────────────────────────
     Exactly three sources, as in the original flight-deck scene: a warm key,
     a cool console fill and a low ambient. No source is added by any effect.
     Emissive strips and displays are visible materials, not scene lights. */
  const key = new THREE.DirectionalLight(0xffdfc2, 2.7);
  key.position.set(3.4, 5.2, 2.2);
  key.target.position.set(0, -0.3, -1.1);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.left = -3;
  key.shadow.camera.right = 3;
  key.shadow.camera.top = 3;
  key.shadow.camera.bottom = -3;
  key.shadow.camera.near = 0.2;
  key.shadow.camera.far = 14;
  key.shadow.bias = -0.0007;
  key.shadow.normalBias = 0.014;
  scene.add(key, key.target);

  const fill = new THREE.PointLight(0x86e3ff, 4.4, 8, 2);
  fill.position.set(-0.55, 0.42, -0.15);
  scene.add(fill);

  const ambient = new THREE.AmbientLight(0x6a828b, 2.15);
  scene.add(ambient);

  /* ── space outside the canopy ───────────────────────────────────────────── */
  const space = new THREE.Group();
  scene.add(space);
  const starsNear = starField(620, 45, 88, 0.14, 17);
  const starsFar = starField(1250, 90, 150, 0.3, 71);
  space.add(starsNear, starsFar);

  const planetTex = planetTexture();
  const planet = new THREE.Mesh(
    new THREE.SphereGeometry(6.4, 96, 64),
    new THREE.MeshBasicMaterial({ map: planetTex, color: 0x7d97a2, toneMapped: false }),
  );
  planet.position.set(11.5, 0.4, -30);
  planet.rotation.set(0.32, -1.15, 0.2);
  space.add(planet);
  const atmoTex = radialSprite('rgba(112,209,255,0)', 'rgba(88,172,220,.38)');
  const atmo = new THREE.Sprite(new THREE.SpriteMaterial({
    map: atmoTex, color: 0xa7e8ff, transparent: true, opacity: 0.5,
    blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false,
  }));
  atmo.position.copy(planet.position);
  atmo.scale.set(19.5, 19.5, 1);
  space.add(atmo);

  const nebulaA = new THREE.Mesh(
    new THREE.PlaneGeometry(120, 80),
    new THREE.MeshBasicMaterial({
      map: nebulaTexture(11, 192), transparent: true, opacity: 0.8,
      depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false,
    }),
  );
  nebulaA.position.set(2, 9, -60);
  space.add(nebulaA);
  const nebulaB = new THREE.Mesh(
    new THREE.PlaneGeometry(96, 96),
    new THREE.MeshBasicMaterial({
      map: nebulaTexture(37, 215), transparent: true, opacity: 0.55,
      depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false,
    }),
  );
  nebulaB.position.set(-18, 2, -56);
  nebulaB.rotation.z = 0.7;
  space.add(nebulaB);

  const sunTex = radialSprite('rgba(255,248,231,1)', 'rgba(255,190,120,.42)');
  const sun = new THREE.Sprite(new THREE.SpriteMaterial({
    map: sunTex, transparent: true, opacity: 1, blending: THREE.AdditiveBlending,
    depthWrite: false, toneMapped: false,
  }));
  sun.position.set(18, 11, -55);
  sun.scale.set(14, 14, 1);
  space.add(sun);
  const sunCore = new THREE.Sprite(new THREE.SpriteMaterial({
    map: sunTex, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending,
    depthWrite: false, toneMapped: false,
  }));
  sunCore.position.copy(sun.position);
  sunCore.scale.set(2.4, 2.4, 1);
  space.add(sunCore);

  // A distant orbital installation, intentionally almost a silhouette.
  const station = new THREE.Group();
  station.position.set(7.5, 2.2, -38);
  station.rotation.set(0.2, -0.7, 0.5);
  const stMat = new THREE.MeshBasicMaterial({ color: 0x39474d, toneMapped: false });
  const st1 = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 4.2, 8), stMat);
  const st2 = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.035, 4, 28), stMat);
  st2.rotation.x = Math.PI / 2.4;
  st2.position.y = 1;
  const st3 = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.03, 0.5), stMat);
  st3.position.y = 1;
  station.add(st1, st2, st3);
  station.scale.setScalar(0.9);
  space.add(station);

  // Interior dust catches the key and adds scale at close range.
  const dustGeo = new THREE.BufferGeometry();
  const dustCount = 90;
  const dustPos = new Float32Array(dustCount * 3);
  for (let i = 0; i < dustCount; i++) {
    dustPos[i * 3] = (Math.random() - 0.5) * 1.6;
    dustPos[i * 3 + 1] = -0.75 + Math.random() * 1.4;
    dustPos[i * 3 + 2] = -1.35 + Math.random() * 1.3;
  }
  dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
  const dust = new THREE.Points(dustGeo, new THREE.PointsMaterial({
    color: 0xcfe6ed, size: 0.0016, transparent: true, opacity: 0.26,
    depthWrite: false, blending: THREE.AdditiveBlending,
  }));
  scene.add(dust);

  /* ── composer ───────────────────────────────────────────────────────────── */
  const composer = new EffectComposer(renderer);
  composer.addPass(new RenderPass(scene, camera));
  const bloom = new UnrealBloomPass(new THREE.Vector2(1024, 1024), 0.22, 0.5, 1.0);
  composer.addPass(bloom);
  composer.addPass(new OutputPass());

  /* ── camera state ───────────────────────────────────────────────────────── */
  const view = STUDY_VIEWS[0];
  const posTarget = new THREE.Vector3(...view.position);
  const lookTarget = new THREE.Vector3(...view.target);
  camera.position.copy(posTarget);
  camera.lookAt(lookTarget);
  let currentFov = view.fov;
  let targetFov = view.fov;

  const pointer = new THREE.Vector2();
  const pointerSmooth = new THREE.Vector2();
  let dragging = false;
  let dragX = 0;
  let dragY = 0;
  let dragYaw = 0;
  let dragPitch = 0;
  let activeDrag = false;

  const onPointerMove = (e: PointerEvent) => {
    const r = canvas.getBoundingClientRect();
    pointer.x = ((e.clientX - r.left) / r.width) * 2 - 1;
    pointer.y = ((e.clientY - r.top) / r.height) * 2 - 1;
    if (activeDrag) {
      dragYaw = THREE.MathUtils.clamp((e.clientX - dragX) / r.width, -0.2, 0.2);
      dragPitch = THREE.MathUtils.clamp((e.clientY - dragY) / r.height, -0.12, 0.12);
    }
  };
  const onPointerDown = (e: PointerEvent) => {
    if (e.button !== 0) return;
    activeDrag = true;
    dragging = true;
    dragX = e.clientX;
    dragY = e.clientY;
    dragYaw = 0;
    dragPitch = 0;
  };
  const onPointerUp = () => {
    activeDrag = false;
    dragging = false;
    dragYaw = 0;
    dragPitch = 0;
  };
  canvas.addEventListener('pointermove', onPointerMove);
  canvas.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('pointerup', onPointerUp);

  /* ── silhouette audit ───────────────────────────────────────────────────── */
  const grayMat = new THREE.MeshStandardMaterial({
    color: 0xd9dad4, roughness: 0.62, metalness: 0.03, envMapIntensity: 0.35,
  });
  const originals = new Map<THREE.Mesh, THREE.Material | THREE.Material[]>();
  const hidden: THREE.Object3D[] = [];
  const glassMeshes: THREE.Mesh[] = [];
  model.group.traverse((o) => {
    if (o instanceof THREE.Mesh && o.material === materials.glass) glassMeshes.push(o);
  });
  let grayscale = false;
  const applyGray = (on: boolean) => {
    grayscale = on;
    if (on) {
      model.group.traverse((o) => {
        if (o instanceof THREE.Mesh) {
          if (!originals.has(o)) originals.set(o, o.material);
          o.material = grayMat;
          o.castShadow = true;
          o.receiveShadow = true;
        }
      });
      hidden.length = 0;
      for (const s of model.screenMeshes) {
        if (s.visible) {
          s.visible = false;
          hidden.push(s);
        }
      }
      for (const d of model.decals) {
        if (d.visible) {
          d.visible = false;
          hidden.push(d);
        }
      }
      for (const g of glassMeshes) {
        if (g.visible) {
          g.visible = false;
          hidden.push(g);
        }
      }
      space.visible = false;
      dust.visible = false;
      scene.background = new THREE.Color(0x8f918c);
      scene.environment = null;
      key.color.set(0xffffff);
      fill.color.set(0xe8eeee);
      ambient.color.set(0xffffff);
      key.intensity = 2.7;
      fill.intensity = 1.7;
      ambient.intensity = 1.05;
      bloom.strength = 0;
    } else {
      originals.forEach((mat, mesh) => {
        mesh.material = mat;
      });
      originals.clear();
      for (const o of hidden) o.visible = true;
      hidden.length = 0;
      space.visible = true;
      dust.visible = true;
      scene.background = new THREE.Color(0x020508);
      key.intensity = 2.7;
      fill.intensity = 4.4;
      ambient.intensity = 2.15;
      bloom.strength = 0.22;
    }
  };

  /* ── responsive ─────────────────────────────────────────────────────────── */
  const resize = () => {
    const w = canvas.clientWidth || 1;
    const h = canvas.clientHeight || 1;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
    renderer.setSize(w, h, false);
    composer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  };
  const ro = new ResizeObserver(resize);
  ro.observe(canvas);
  resize();

  /* ── animation ──────────────────────────────────────────────────────────── */
  let raf = 0;
  let disposed = false;
  let last = performance.now();
  let elapsed = 0;
  let calloutActive = true;

  const animate = (now: number) => {
    if (disposed) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    elapsed += dt;
    pointerSmooth.lerp(pointer, 1 - Math.pow(0.001, dt));

    const desiredPos = posTarget.clone().add(new THREE.Vector3(
      pointerSmooth.x * 0.035 + dragYaw * 0.4,
      -pointerSmooth.y * 0.022 + dragPitch * 0.2 + Math.sin(elapsed * 0.55) * 0.0035,
      0,
    ));
    const desiredLook = lookTarget.clone().add(new THREE.Vector3(
      pointerSmooth.x * 0.035 + dragYaw * 0.3,
      -pointerSmooth.y * 0.018 + dragPitch * 0.16,
      0,
    ));
    camera.position.lerp(desiredPos, 1 - Math.pow(0.002, dt));
    const look = new THREE.Vector3();
    look.copy(camera.position).lerp(desiredLook, 1);
    camera.lookAt(look);
    camera.fov += (targetFov - camera.fov) * (1 - Math.pow(0.004, dt));
    if (Math.abs(targetFov - currentFov) > 0.01) {
      currentFov = targetFov;
      camera.updateProjectionMatrix();
    }

    starsNear.rotation.y = elapsed * 0.0018;
    starsFar.rotation.y = -elapsed * 0.0009;
    dust.rotation.y = Math.sin(elapsed * 0.12) * 0.05;
    sun.material.opacity = 0.95 + Math.sin(elapsed * 1.7) * 0.03;
    if (!grayscale) {
      for (const m of model.ledMaterials) {
        m.emissiveIntensity = 0.24 + Math.sin(elapsed * 2.2) * 0.07;
      }
    }

    composer.render(dt);
    raf = requestAnimationFrame(animate);
  };
  raf = requestAnimationFrame(animate);

  const setView = (id: ViewId) => {
    const v = STUDY_VIEWS.find((x) => x.id === id);
    if (!v) return;
    posTarget.set(...v.position);
    lookTarget.set(...v.target);
    targetFov = v.fov;
    dragYaw = 0;
    dragPitch = 0;
  };

  let activeSection = STUDY_VIEWS[0].id ? ('flight' as const) : ('flight' as const);
  void activeSection;
  let lastSection: CockpitSection | null = null;
  let throttle = 0.62;

  return {
    setView,
    setSection: (section) => {
      lastSection = section;
      model.updateScreen(section, throttle);
    },
    setThrottle: (v) => {
      throttle = THREE.MathUtils.clamp(v, 0, 1);
      model.setThrottle(throttle);
      if (lastSection) model.updateScreen(lastSection, throttle);
    },
    setGrayscale: applyGray,
    setCalloutActive: (v) => {
      calloutActive = v;
      void calloutActive;
    },
    refreshScreens: () => {
      if (lastSection) model.updateScreen(lastSection, throttle);
    },
    dispose: () => {
      disposed = true;
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvas.removeEventListener('pointermove', onPointerMove);
      canvas.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointerup', onPointerUp);
      void dragging;
      model.group.traverse((o) => {
        if (o instanceof THREE.Mesh) {
          o.geometry.dispose();
        }
      });
      model.dispose();
      for (const m of materials.all) m.dispose();
      envRT.dispose();
      grayMat.dispose();
      planetTex.dispose();
      atmoTex.dispose();
      sunTex.dispose();
      nebulaA.geometry.dispose();
      nebulaB.geometry.dispose();
      (nebulaA.material as THREE.Material).dispose();
      (nebulaB.material as THREE.Material).dispose();
      scene.traverse((o) => {
        if (o instanceof THREE.Points) {
          o.geometry.dispose();
          (o.material as THREE.Material).dispose();
        }
        if (o instanceof THREE.Sprite) {
          (o.material as THREE.Material).dispose();
        }
      });
      composer.dispose();
      renderer.dispose();
    },
  };
}
