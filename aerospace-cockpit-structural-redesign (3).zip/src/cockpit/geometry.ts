import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';

export type ProfilePoint = [number, number];

/** Sweep an arbitrary closed 2D section along a 3D path using a stable up-vector
 *  frame. This is the workhorse for C-channels, seals, grab rails and hoses. */
export function sweepProfile(
  points: THREE.Vector3[] | THREE.CatmullRomCurve3,
  profile: ProfilePoint[],
  opts: {
    steps?: number;
    up?: THREE.Vector3;
    closedPath?: boolean;
    caps?: boolean;
    profileClosed?: boolean;
  } = {},
): THREE.BufferGeometry {
  const curve =
    points instanceof THREE.CatmullRomCurve3
      ? points
      : new THREE.CatmullRomCurve3(points, opts.closedPath ?? false, 'centripetal', 0.5);
  const steps = opts.steps ?? Math.max(24, Math.round(profile.length * 8));
  const up = (opts.up ?? new THREE.Vector3(0, 1, 0)).clone().normalize();
  const closedProfile = opts.profileClosed ?? true;
  const positions: number[] = [];
  const uvs: number[] = [];
  const side = new THREE.Vector3();
  const lift = new THREE.Vector3();
  const tangent = new THREE.Vector3();
  const radial = new THREE.Vector3(0, 1, 0);

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    curve.getPointAt(t, radial);
    curve.getTangentAt(t, tangent).normalize();
    side.crossVectors(tangent, up).normalize();
    if (side.lengthSq() < 1e-5) side.set(1, 0, 0);
    lift.crossVectors(side, tangent).normalize();
    for (let j = 0; j < profile.length; j++) {
      const [px, py] = profile[j];
      positions.push(
        radial.x + side.x * px + lift.x * py,
        radial.y + side.y * px + lift.y * py,
        radial.z + side.z * px + lift.z * py,
      );
      uvs.push(j / profile.length, t);
    }
  }

  const indices: number[] = [];
  const n = profile.length;
  const ringCount = steps + 1;
  for (let i = 0; i < steps; i++) {
    for (let j = 0; j < n; j++) {
      const j2 = closedProfile ? (j + 1) % n : Math.min(j + 1, n - 1);
      const a = i * n + j;
      const b = i * n + j2;
      const c = (i + 1) * n + j;
      const d = (i + 1) * n + j2;
      indices.push(a, c, b, b, c, d);
    }
  }

  if (opts.caps && !opts.closedPath) {
    const cap = (ringStart: number, reverse: boolean) => {
      const centerIndex = positions.length / 3;
      const cx = positions.slice(ringStart * 3, ringStart * 3 + 3);
      positions.push(cx[0], cx[1], cx[2]);
      uvs.push(0.5, 0.5);
      for (let j = 0; j < n; j++) {
        const j2 = (j + 1) % n;
        const a = ringStart + j;
        const b = ringStart + j2;
        if (reverse) indices.push(centerIndex, b, a);
        else indices.push(centerIndex, a, b);
      }
    };
    cap(0, true);
    cap(steps * n, false);
  }
  void ringCount;

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/** Loft a smooth surface from a parametric function (u,v) → point. */
export function loftSurface(
  fn: (u: number, v: number, out: THREE.Vector3) => void,
  uSeg = 32,
  vSeg = 20,
  closeU = false,
): THREE.BufferGeometry {
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  const p = new THREE.Vector3();
  for (let i = 0; i <= uSeg; i++) {
    const u = i / uSeg;
    for (let j = 0; j <= vSeg; j++) {
      const v = j / vSeg;
      fn(u, v, p);
      positions.push(p.x, p.y, p.z);
      uvs.push(u * 2, v * 2);
    }
  }
  const stride = vSeg + 1;
  const uCount = closeU ? uSeg : uSeg;
  for (let i = 0; i < uCount; i++) {
    for (let j = 0; j < vSeg; j++) {
      const a = i * stride + j;
      const b = a + stride;
      indices.push(a, b, a + 1, b, b + 1, a + 1);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

export function roundedRectShape(w: number, h: number, r: number): THREE.Shape {
  const s = new THREE.Shape();
  const x = -w / 2;
  const y = -h / 2;
  const rr = Math.min(r, w / 2, h / 2);
  s.moveTo(x + rr, y);
  s.lineTo(x + w - rr, y);
  s.quadraticCurveTo(x + w, y, x + w, y + rr);
  s.lineTo(x + w, y + h - rr);
  s.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  s.lineTo(x + rr, y + h);
  s.quadraticCurveTo(x, y + h, x, y + h - rr);
  s.lineTo(x, y + rr);
  s.quadraticCurveTo(x, y, x + rr, y);
  return s;
}

export function panelGeometry(
  w: number,
  h: number,
  r: number,
  depth: number,
  bevel = 0.006,
): THREE.ExtrudeGeometry {
  return new THREE.ExtrudeGeometry(roundedRectShape(w, h, r), {
    depth,
    bevelEnabled: true,
    bevelSize: bevel,
    bevelThickness: bevel,
    bevelSegments: 2,
    curveSegments: 10,
  });
}

export function shapeExtrude(
  shape: THREE.Shape,
  depth: number,
  bevel = 0.005,
): THREE.ExtrudeGeometry {
  return new THREE.ExtrudeGeometry(shape, {
    depth,
    bevelEnabled: bevel > 0,
    bevelSize: bevel,
    bevelThickness: bevel,
    bevelSegments: 2,
    curveSegments: 14,
  });
}

export function roundedBox(w: number, h: number, d: number, r = 0.01, seg = 3): RoundedBoxGeometry {
  return new RoundedBoxGeometry(w, h, d, seg, r);
}

/** A washer-and-hex fastener, reused everywhere to keep hardware consistent. */
export function boltGeometry(radius = 0.0065, height = 0.005): THREE.BufferGeometry {
  return new THREE.CylinderGeometry(radius, radius, height, 6);
}

export function boltWasherGeometry(radius = 0.0095): THREE.CylinderGeometry {
  return new THREE.CylinderGeometry(radius, radius, 0.0016, 18);
}

export interface BoltPlacement {
  position: THREE.Vector3;
  normal: THREE.Vector3;
  scale?: number;
}

export function fastenerInstances(
  placements: BoltPlacement[],
  material: THREE.Material,
  radius = 0.0065,
  height = 0.005,
): THREE.Group {
  const group = new THREE.Group();
  const bolt = new THREE.InstancedMesh(boltGeometry(radius, height), material, placements.length);
  const washer = new THREE.InstancedMesh(boltWasherGeometry(radius * 1.55), material, placements.length);
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const up = new THREE.Vector3(0, 1, 0);
  const s = new THREE.Vector3(1, 1, 1);
  placements.forEach((p, i) => {
    q.setFromUnitVectors(up, p.normal.clone().normalize());
    const sc = p.scale ?? 1;
    s.set(sc, sc, sc);
    m.compose(p.position, q, s);
    bolt.setMatrixAt(i, m);
    m.compose(
      p.position.clone().addScaledVector(p.normal.clone().normalize(), -height * 0.42),
      q,
      s,
    );
    washer.setMatrixAt(i, m);
  });
  bolt.instanceMatrix.needsUpdate = true;
  washer.instanceMatrix.needsUpdate = true;
  group.add(bolt, washer);
  return group;
}

export function buildKnob(
  radius: number,
  height: number,
  material: THREE.Material,
  accent: THREE.Material,
): THREE.Group {
  const g = new THREE.Group();
  const profile: THREE.Vector2[] = [];
  profile.push(new THREE.Vector2(radius * 0.72, 0));
  profile.push(new THREE.Vector2(radius * 0.96, height * 0.1));
  profile.push(new THREE.Vector2(radius * 1.02, height * 0.2));
  for (let i = 0; i < 10; i++) {
    profile.push(new THREE.Vector2(i % 2 ? radius : radius * 1.035, height * (0.28 + i * 0.055)));
  }
  profile.push(new THREE.Vector2(radius * 0.88, height));
  const body = new THREE.Mesh(new THREE.LatheGeometry(profile, 32), material);
  g.add(body);
  const cap = new THREE.Mesh(new THREE.TorusGeometry(radius * 0.78, radius * 0.055, 6, 28), accent);
  cap.rotation.x = Math.PI / 2;
  cap.position.y = height + 0.0005;
  g.add(cap);
  const pointer = new THREE.Mesh(new THREE.BoxGeometry(radius * 0.16, 0.002, radius * 0.62), accent);
  pointer.position.set(0, height + 0.003, -radius * 0.36);
  g.add(pointer);
  return g;
}

export function buildToggle(
  metal: THREE.Material,
  cap: THREE.Material,
  guard: THREE.Material | null,
): THREE.Group {
  const g = new THREE.Group();
  const nut = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.013, 0.006, 6), metal);
  nut.position.y = 0.004;
  g.add(nut);
  const washer = new THREE.Mesh(new THREE.CylinderGeometry(0.0145, 0.0145, 0.0015, 16), metal);
  washer.position.y = 0.0008;
  g.add(washer);
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.0042, 0.0055, 0.026, 10), metal);
  stem.position.y = 0.02;
  stem.rotation.z = 0.24;
  stem.position.x = 0.002;
  g.add(stem);
  const tip = new THREE.Mesh(new THREE.CylinderGeometry(0.0058, 0.0042, 0.013, 12), cap);
  tip.position.set(0.0095, 0.036, 0);
  tip.rotation.z = 0.24;
  g.add(tip);
  if (guard) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.026, 0.0032, 6, 20, Math.PI * 1.1), guard);
    ring.rotation.set(Math.PI / 2, 0.9, 0.15);
    ring.position.set(0.005, 0.034, 0);
    g.add(ring);
    const armL = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, 0.03, 8), guard);
    armL.position.set(-0.018, 0.024, 0);
    armL.rotation.z = 0.25;
    g.add(armL);
    const armR = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, 0.03, 8), guard);
    armR.position.set(0.028, 0.024, 0);
    armR.rotation.z = -0.25;
    g.add(armR);
  }
  return g;
}

export function tube(
  points: THREE.Vector3[],
  radius: number,
  material: THREE.Material,
  radial = 8,
  tubular = 48,
): THREE.Mesh {
  const curve = new THREE.CatmullRomCurve3(points, false, 'centripetal', 0.5);
  return new THREE.Mesh(new THREE.TubeGeometry(curve, tubular, radius, radial, false), material);
}

export function makeLabelPlane(
  texture: THREE.Texture,
  w: number,
  h: number,
  opacity = 1,
): THREE.Mesh {
  const mat = new THREE.MeshBasicMaterial({
    map: texture,
    transparent: true,
    opacity,
    depthWrite: false,
    toneMapped: false,
    side: THREE.DoubleSide,
  });
  return new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
}
