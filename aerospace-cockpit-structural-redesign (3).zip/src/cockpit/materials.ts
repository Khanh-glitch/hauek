import * as THREE from 'three';
import {
  brushedMetalMap,
  leatherMap,
  treadMap,
  weaveMap,
} from './textures';

export interface MaterialLibrary {
  hull: THREE.MeshStandardMaterial;
  shell: THREE.MeshStandardMaterial;
  panel: THREE.MeshStandardMaterial;
  anodized: THREE.MeshStandardMaterial;
  brushed: THREE.MeshStandardMaterial;
  titanium: THREE.MeshStandardMaterial;
  carbon: THREE.MeshPhysicalMaterial;
  fabric: THREE.MeshStandardMaterial;
  leather: THREE.MeshStandardMaterial;
  rubber: THREE.MeshStandardMaterial;
  seal: THREE.MeshStandardMaterial;
  glass: THREE.MeshPhysicalMaterial;
  screenGlass: THREE.MeshPhysicalMaterial;
  bezel: THREE.MeshStandardMaterial;
  dark: THREE.MeshStandardMaterial;
  warm: THREE.MeshStandardMaterial;
  cyan: THREE.MeshStandardMaterial;
  red: THREE.MeshStandardMaterial;
  green: THREE.MeshStandardMaterial;
  white: THREE.MeshStandardMaterial;
  labels: THREE.MeshBasicMaterial;
  warmLight: THREE.MeshBasicMaterial;
  coolLight: THREE.MeshBasicMaterial;
  caution: THREE.MeshStandardMaterial;
  floor: THREE.MeshStandardMaterial;
  disposables: { dispose: () => void }[];
  all: THREE.Material[];
}

export function buildMaterials(): MaterialLibrary {
  const disposables: { dispose: () => void }[] = [];
  const trackTex = <T extends THREE.Texture>(t: T): T => {
    disposables.push(t);
    return t;
  };
  const trackMat = <T extends THREE.Material>(m: T): T => {
    disposables.push(m);
    return m;
  };

  const brushed = trackTex(brushedMetalMap(9));
  const leather = trackTex(leatherMap());
  const weave = trackTex(weaveMap(true));
  const fabricWeave = trackTex(weaveMap(false));
  const tread = trackTex(treadMap());

  const hull = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x2b3336,
      roughness: 0.62,
      metalness: 0.44,
      roughnessMap: brushed,
      bumpMap: brushed,
      bumpScale: 0.16,
      envMapIntensity: 0.72,
    }),
  );

  const shell = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x4a565e,
      roughness: 0.62,
      metalness: 0.26,
      roughnessMap: brushed,
      bumpMap: brushed,
      bumpScale: 0.14,
      envMapIntensity: 0.8,
    }),
  );

  const panel = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x2b343a,
      roughness: 0.5,
      metalness: 0.55,
      roughnessMap: brushed,
      bumpMap: brushed,
      bumpScale: 0.22,
      envMapIntensity: 1.1,
    }),
  );

  const anodized = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x151b1f,
      roughness: 0.4,
      metalness: 0.8,
      roughnessMap: brushed,
      envMapIntensity: 1.25,
    }),
  );

  const brushed2 = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x8d979a,
      roughness: 0.38,
      metalness: 0.88,
      roughnessMap: brushed,
      bumpMap: brushed,
      bumpScale: 0.06,
      envMapIntensity: 1.15,
    }),
  );

  const titanium = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x6d7579,
      roughness: 0.44,
      metalness: 0.86,
      roughnessMap: brushed,
      bumpMap: brushed,
      bumpScale: 0.1,
      envMapIntensity: 1.3,
    }),
  );

  const carbon = trackMat(
    new THREE.MeshPhysicalMaterial({
      color: 0x15181b,
      roughness: 0.44,
      metalness: 0.3,
      roughnessMap: weave,
      bumpMap: weave,
      bumpScale: 0.24,
      clearcoat: 0.5,
      clearcoatRoughness: 0.34,
      envMapIntensity: 0.9,
    }),
  );

  const fabric = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x2f3539,
      roughness: 0.94,
      metalness: 0.04,
      roughnessMap: fabricWeave,
      bumpMap: fabricWeave,
      bumpScale: 0.32,
      envMapIntensity: 0.4,
    }),
  );

  const leatherMat = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x1b1e20,
      roughness: 0.78,
      metalness: 0.03,
      roughnessMap: leather,
      bumpMap: leather,
      bumpScale: 0.34,
      envMapIntensity: 0.5,
    }),
  );

  const rubber = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x0c0f10,
      roughness: 0.9,
      metalness: 0.02,
      envMapIntensity: 0.3,
    }),
  );

  const seal = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x0a0c0d,
      roughness: 0.72,
      metalness: 0.05,
      bumpMap: leather,
      bumpScale: 0.12,
      envMapIntensity: 0.4,
    }),
  );

  const glass = trackMat(
    new THREE.MeshPhysicalMaterial({
      color: 0x9fc7d3,
      roughness: 0.05,
      metalness: 0.0,
      transparent: true,
      opacity: 0.02,
      transmission: 0.0,
      envMapIntensity: 1.0,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );

  const screenGlass = trackMat(
    new THREE.MeshPhysicalMaterial({
      color: 0x9ec8d4,
      roughness: 0.08,
      metalness: 0,
      transparent: true,
      opacity: 0.032,
      envMapIntensity: 1.2,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );

  const bezel = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x0d1114,
      roughness: 0.52,
      metalness: 0.55,
      envMapIntensity: 0.8,
    }),
  );

  const dark = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x141a1e,
      roughness: 0.8,
      metalness: 0.18,
      envMapIntensity: 0.4,
    }),
  );

  const warm = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x4a3523,
      roughness: 0.48,
      metalness: 0.6,
      emissive: 0xffab5a,
      emissiveIntensity: 0.16,
      envMapIntensity: 0.8,
    }),
  );
  const cyan = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x1b3c44,
      roughness: 0.36,
      metalness: 0.5,
      emissive: 0x74e8ff,
      emissiveIntensity: 0.38,
      envMapIntensity: 1,
    }),
  );
  const red = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x3a1410,
      roughness: 0.5,
      metalness: 0.2,
      emissive: 0xff4740,
      emissiveIntensity: 0.28,
    }),
  );
  const green = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x12372c,
      roughness: 0.5,
      metalness: 0.2,
      emissive: 0x5cffc0,
      emissiveIntensity: 0.3,
    }),
  );
  const white = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0xd0e2e6,
      roughness: 0.4,
      metalness: 0.35,
    }),
  );

  const labels = trackMat(
    new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.82,
      depthWrite: false,
      toneMapped: false,
    }),
  );
  const warmLight = trackMat(
    new THREE.MeshBasicMaterial({ color: 0xffc16b, toneMapped: false }),
  );
  const coolLight = trackMat(
    new THREE.MeshBasicMaterial({ color: 0x7ce6ff, toneMapped: false }),
  );
  const caution = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x8b4b12,
      roughness: 0.55,
      metalness: 0.4,
      emissive: 0x3d1c03,
      emissiveIntensity: 0.4,
    }),
  );

  const floor = trackMat(
    new THREE.MeshStandardMaterial({
      color: 0x2b3236,
      roughness: 0.72,
      metalness: 0.55,
      roughnessMap: tread,
      bumpMap: tread,
      bumpScale: 0.5,
      envMapIntensity: 0.7,
    }),
  );

  const all = [
    hull, shell, panel, anodized, brushed2, titanium, carbon, fabric,
    leatherMat, rubber, seal, glass, screenGlass, bezel, dark, warm, cyan,
    red, green, white, labels, warmLight, coolLight, caution, floor,
  ];

  return {
    hull,
    shell,
    panel,
    anodized,
    brushed: brushed2,
    titanium,
    carbon,
    fabric,
    leather: leatherMat,
    rubber,
    seal,
    glass,
    screenGlass,
    bezel,
    dark,
    warm,
    cyan,
    red,
    green,
    white,
    labels,
    warmLight,
    coolLight,
    caution,
    floor,
    disposables,
    all,
  };
}
