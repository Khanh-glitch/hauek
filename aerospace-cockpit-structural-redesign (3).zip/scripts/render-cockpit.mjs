#!/usr/bin/env node
/* ─────────────────────────────────────────────────────────────────────────────
   render-cockpit.mjs — offline CPU rasteriser for geometry review.

   WHY THIS EXISTS
   The build environment has no browser and no GPU. This script builds a
   Three.js scene graph of the cockpit *massing* (the same coordinate system,
   panel planes, canopy aperture, seat, pedestal and rails used by
   src/cockpit/cockpit.ts), traverses it exactly as a renderer would, and
   software-rasterises it into PNG files with a z-buffer and one directional
   light. It is an acceptance aid for silhouette and proportion.

   WHAT IT DOES NOT PROVE
   • It is NOT a WebGL screenshot. It does not evaluate the app's materials,
     physical shading, environment maps, bloom, transparency or textures.
   • The mesh set here is a deliberately simplified survey of the massing, not
     the full interactive scene. Small hardware, decals and screen paint are
     absent, so thin parts read differently than in the browser.
   • No timing, draw-call or frame-rate claim can be made from it.
   • Passing these images is not a human-factors, structural or flight
     qualification test.

   USAGE
     node scripts/render-cockpit.mjs              # all four study views
     node scripts/render-cockpit.mjs --view pilot # one view
   Output: renders/cockpit-<view>.png
   ──────────────────────────────────────────────────────────────────────────── */

import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';
import * as THREE from 'three';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const OUT_DIR = path.resolve(__dirname, '..', 'renders');
const WIDTH = 960;
const HEIGHT = 600;

const VIEWS = {
  pilot: { pos: [0, 0.115, 0.56], target: [0, -0.075, -1.25], fov: 58 },
  command: { pos: [0.4, 0.07, 0.55], target: [-0.06, -0.09, -1.18], fov: 55 },
  overhead: { pos: [0.3, 0.6, 0.78], target: [0, -0.4, -0.9], fov: 62 },
  detail: { pos: [0.05, 0.02, -0.12], target: [-0.44, -0.33, -0.95], fov: 44 },
};

const MAT = {
  hull: [0.36, 0.41, 0.43],
  panel: [0.22, 0.27, 0.3],
  dark: [0.12, 0.14, 0.16],
  metal: [0.7, 0.75, 0.76],
  seat: [0.3, 0.34, 0.36],
  floor: [0.24, 0.27, 0.28],
};

function mesh(geo, color, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, parent) {
  const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial());
  m.material.userData.color = color;
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  (parent ?? root).add(m);
  return m;
}

const box = (w, h, d, color, x, y, z, rx = 0, ry = 0, rz = 0, parent) =>
  mesh(new THREE.BoxGeometry(w, h, d), color, x, y, z, rx, ry, rz, parent);

const cyl = (rt, rb, h, seg, color, x, y, z, rx = 0, ry = 0, rz = 0, parent) =>
  mesh(new THREE.CylinderGeometry(rt, rb, h, seg), color, x, y, z, rx, ry, rz, parent);

const root = new THREE.Group();

/* Massing mirrors the interactive build (metres, camera origin, -Z forward).
   See src/cockpit/cockpit.ts for the full assembly. */
// Deck
box(2.24, 0.075, 2.75, MAT.floor, 0, -0.96, -0.34);
box(1.36, 0.038, 0.92, MAT.metal, 0, -0.91, -1.02);
// Side skins, ribs and coaming
for (const s of [-1, 1]) {
  box(0.06, 0.75, 2.7, MAT.hull, s * 0.78, -0.55, -0.3, 0, 0, s * 0.04);
  for (let i = 0; i < 5; i++) box(0.05, 0.6, 0.05, MAT.panel, s * 0.74, -0.6, -1.3 + i * 0.55);
  for (let i = 0; i < 4; i++) box(0.42, 0.24, 0.02, MAT.panel, s * 0.73, -0.35, -1.1 + i * 0.5);
  box(0.1, 0.06, 2.6, MAT.metal, s * 0.8, -0.33, -0.3);
  box(0.13, 0.45, 0.6, MAT.seat, s * 0.7, -0.58, 0.0);
  // canopy post
  const post = new THREE.Group();
  post.position.set(s * 0.8, 0, 0);
  root.add(post);
  for (let i = 0; i < 6; i++) {
    mesh(new THREE.BoxGeometry(0.05, 0.16, 0.055), MAT.hull,
      s * 0.8 + i * s * 0.02, -0.1 + i * 0.14, -1.05 - i * 0.07, 0.2, 0, 0);
  }
}
// Header beam and A-pillar masses
for (let i = 0; i < 9; i++) box(0.2, 0.055, 0.06, MAT.hull, -0.78 + i * 0.195, 0.76, -1.7, 0, 0, 0);
// Aft bulkhead
box(1.9, 1.2, 0.08, MAT.hull, 0, -0.32, 1.28);
box(0.78, 0.76, 0.04, MAT.panel, 0, -0.33, 1.2);
// Overhead rails (open sky kept between them)
for (const s of [-1, 1]) {
  for (let i = 0; i < 9; i++) {
    box(0.06, 0.05, 0.3, MAT.hull, s * 0.33, 0.83, -1.2 + i * 0.27);
  }
}
// Dash monocoque (tilted 15°)
const dash = new THREE.Group();
dash.position.set(0, -0.275, -1.235);
dash.rotation.x = -0.16;
root.add(dash);
box(1.68, 0.34, 0.26, MAT.hull, 0, -0.05, -0.03, 0, 0, 0, dash);
box(1.5, 0.24, 0.13, MAT.seat, 0, -0.44, 0.04, 0, 0, 0, dash);
// display plane and bezels
box(0.78, 0.44, 0.03, MAT.dark, 0, -0.065, 0.11, 0, 0, 0, dash);
box(0.66, 0.33, 0.012, MAT.panel, 0, -0.065, 0.13, 0, 0, 0, dash);
for (const s of [-1, 1]) box(0.28, 0.22, 0.03, MAT.dark, s * 0.565, -0.075, 0.1, 0, s * -0.26, 0, dash);
// glareshield
for (let i = 0; i < 12; i++) {
  const x = -0.85 + i * 0.155;
  box(0.16, 0.05, 0.22, MAT.seat, x, -0.14 - (x / 0.95) ** 2 * 0.05, -1.13 - (x / 0.98) ** 2 * 0.06);
}
// Pedestal
const ped = new THREE.Group();
ped.position.set(0, -0.6, -0.42);
root.add(ped);
box(0.45, 0.22, 0.68, MAT.panel, 0, 0, 0, 0, 0, 0, ped);
box(0.48, 0.032, 0.7, MAT.metal, 0, 0.12, 0, 0, 0, 0, ped);
for (let i = 0; i < 2; i++) {
  box(0.022, 0.13, 0.05, MAT.metal, -0.11 + i * 0.075, 0.19, 0.12, 0, 0, 0, ped);
  box(0.045, 0.07, 0.05, MAT.dark, -0.11 + i * 0.075, 0.27, 0.12, 0, 0, 0, ped);
}
// Seat: shell, cushions, headrest, rails
const seat = new THREE.Group();
seat.position.set(0, 0, 0.78);
root.add(seat);
box(0.54, 0.6, 0.1, MAT.seat, 0, 0.05, 0.35, -0.19, 0, 0, seat);
box(0.54, 0.2, 0.52, MAT.seat, 0, -0.48, -0.02, 0, 0, 0, seat);
box(0.42, 0.16, 0.5, MAT.seat, 0, -0.56, 0.0, 0, 0, 0, seat);
box(0.36, 0.19, 0.12, MAT.seat, 0, 0.72, 0.46, -0.16, 0, 0, seat);
for (const s of [-1, 1]) {
  box(0.11, 0.36, 0.12, MAT.seat, s * 0.29, 0.05, 0.3, -0.19, 0, 0, seat);
  box(0.1, 0.05, 0.45, MAT.seat, s * 0.39, -0.22, -0.02, 0, 0, 0, seat);
  box(0.07, 0.06, 0.92, MAT.dark, s * 0.29, -0.855, 0.03, 0, 0, 0, seat);
  box(0.1, 0.09, 0.2, MAT.metal, s * 0.29, -0.79, 0.16, 0, 0, 0, seat);
}
// Pedals
for (const s of [-1, 1]) {
  box(0.18, 0.22, 0.026, MAT.metal, s * 0.26, -0.84, -1.02, Math.PI / 2 - 0.34, 0, 0);
  box(0.2, 0.035, 0.035, MAT.metal, s * 0.26, -0.79, -1.12, 0, 0, Math.PI / 2);
}
// Translational controller
cyl(0.1, 0.115, 0.035, 20, MAT.metal, 0.38, -0.62, -0.35);
cyl(0.026, 0.026, 0.13, 12, MAT.dark, 0.38, -0.53, -0.35);

/* ── renderer ───────────────────────────────────────────────────────────────── */

function crc32(buf) {
  let c = ~0;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xedb88320 & -(c & 1));
  }
  return ~c >>> 0;
}

function png(width, height, rgb) {
  const raw = Buffer.alloc((width * 3 + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (width * 3 + 1)] = 0;
    rgb.copy(raw, y * (width * 3 + 1) + 1, y * width * 3, (y + 1) * width * 3);
  }
  const chunk = (type, data) => {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(body));
    return Buffer.concat([len, body, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 2;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

function renderView(view, name) {
  const r = { ...VIEWS[view] };
  if (!r.pos) throw new Error(`Unknown view: ${view}`);
  const camera = new THREE.PerspectiveCamera(r.fov, WIDTH / HEIGHT, 0.04, 100);
  camera.position.set(...r.pos);
  camera.lookAt(new THREE.Vector3(...r.target));
  camera.updateMatrixWorld(true);
  root.updateMatrixWorld(true);
  const viewMatrix = camera.matrixWorldInverse;
  const proj = camera.projectionMatrix;
  const mvp = new THREE.Matrix4().multiplyMatrices(proj, viewMatrix);

  const color = Buffer.alloc(WIDTH * HEIGHT * 3);
  const depth = new Float32Array(WIDTH * HEIGHT).fill(Infinity);
  // Background: neutral grey. This is a geometry audit render, not a beauty pass.
  for (let i = 0; i < WIDTH * HEIGHT; i++) {
    color[i * 3] = 176;
    color[i * 3 + 1] = 178;
    color[i * 3 + 2] = 176;
  }

  const lightDir = new THREE.Vector3(0.45, 0.8, 0.4).normalize();
  const v = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()];
  const p = new THREE.Vector3();
  const n = new THREE.Vector3();
  const cb = new THREE.Vector3();
  const ca = new THREE.Vector3();

  let triangles = 0;
  root.traverse((obj) => {
    if (!obj.isMesh) return;
    const geo = obj.geometry;
    const pos = geo.getAttribute('position');
    const index = geo.getIndex();
    const baseColor = obj.material.userData.color ?? [0.5, 0.5, 0.5];
    const count = index ? index.count : pos.count;
    for (let i = 0; i < count; i += 3) {
      const ids = [index ? index.getX(i) : i, index ? index.getX(i + 1) : i + 1, index ? index.getX(i + 2) : i + 2];
      const screen = [];
      let visible = true;
      for (let k = 0; k < 3; k++) {
        v[k].fromBufferAttribute(pos, ids[k]).applyMatrix4(obj.matrixWorld);
        p.copy(v[k]).applyMatrix4(mvp);
        if (p.z < -1 || p.z > 1) { visible = false; break; }
        screen.push([(p.x * 0.5 + 0.5) * WIDTH, (-p.y * 0.5 + 0.5) * HEIGHT, p.z]);
      }
      if (!visible) continue;
      cb.subVectors(v[2], v[1]);
      ca.subVectors(v[1], v[0]);
      n.crossVectors(cb, ca).normalize();
      const viewDir = new THREE.Vector3().subVectors(camera.position, v[0]).normalize();
      if (n.dot(viewDir) < 0) n.negate();
      const lambert = Math.max(0, n.dot(lightDir)) * 0.7 + 0.28;
      const fill = Math.max(0, n.dot(new THREE.Vector3(-0.6, 0.1, 0.7).normalize())) * 0.18;
      const shade = Math.min(1.35, lambert + fill);
      const minX = Math.max(0, Math.floor(Math.min(screen[0][0], screen[1][0], screen[2][0])));
      const maxX = Math.min(WIDTH - 1, Math.ceil(Math.max(screen[0][0], screen[1][0], screen[2][0])));
      const minY = Math.max(0, Math.floor(Math.min(screen[0][1], screen[1][1], screen[2][1])));
      const maxY = Math.min(HEIGHT - 1, Math.ceil(Math.max(screen[0][1], screen[1][1], screen[2][1])));
      const ax = screen[0][0], ay = screen[0][1];
      const bx = screen[1][0], by = screen[1][1];
      const cx = screen[2][0], cy = screen[2][1];
      const area = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
      if (Math.abs(area) < 1e-9) continue;
      triangles++;
      for (let y = minY; y <= maxY; y++) {
        for (let x = minX; x <= maxX; x++) {
          const w0 = ((bx - x) * (cy - y) - (by - y) * (cx - x)) / area;
          const w1 = ((cx - x) * (ay - y) - (cy - y) * (ax - x)) / area;
          const w2 = 1 - w0 - w1;
          if (w0 < -0.001 || w1 < -0.001 || w2 < -0.001) continue;
          const z = w0 * screen[0][2] + w1 * screen[1][2] + w2 * screen[2][2];
          const pix = y * WIDTH + x;
          if (z >= depth[pix]) continue;
          depth[pix] = z;
          // Machined edge accent: darker where the surface turns away strongly.
          const edge = Math.abs(n.z) < 0.18 ? 0.78 : 1;
          color[pix * 3] = Math.min(255, baseColor[0] * shade * edge * 255);
          color[pix * 3 + 1] = Math.min(255, baseColor[1] * shade * edge * 255);
          color[pix * 3 + 2] = Math.min(255, baseColor[2] * shade * edge * 255);
        }
      }
    }
  });

  fs.mkdirSync(OUT_DIR, { recursive: true });
  const file = path.join(OUT_DIR, `cockpit-${name}.png`);
  fs.writeFileSync(file, png(WIDTH, HEIGHT, color));
  console.log(`[cpu-raster] ${file}  ${triangles} visible triangles  ${WIDTH}x${HEIGHT}`);
  console.log('[cpu-raster] NOTE: geometry massing only — not WebGL, materials or performance evidence.');
}

const idx = process.argv.indexOf('--view');
const wanted = idx !== -1 ? [process.argv[idx + 1]] : Object.keys(VIEWS);
for (const name of wanted) {
  if (!VIEWS[name]) {
    console.error(`Unknown view "${name}". Options: ${Object.keys(VIEWS).join(', ')}`);
    process.exit(1);
  }
  renderView(name, name);
}
